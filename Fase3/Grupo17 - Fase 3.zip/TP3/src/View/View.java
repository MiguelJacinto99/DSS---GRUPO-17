package View;

import java.util.Collection;
import RacingManagerLN.Campeonatos.*;
import RacingManagerLN.Corridas.Circuito;

public class View {

    public static void menuInicial(){
        System.out.println("\n\n\n\n\n\n\n\n");
        System.out.println("____________________________________________________________________________");
        System.out.println("|                                                                           |");
        System.out.println("|                                RacingManager                              |");
        System.out.println("|___________________________________________________________________________|");
        System.out.println("|                                                                           |");
        System.out.println("|        1. Entrar como administador                                        |");
        System.out.println("|        2. Entrar como jogador                                             |");
        System.out.println("|        3. Registar jogador                                                |");
        System.out.println("|        0. Voltar ao Menu principal                                        |");
        System.out.println("|___________________________________________________________________________|");
        System.out.print("Digite a sua opção\n>");
    }

    public static void login(){
        System.out.println("\n\n\n\n\n\n\n\n");
        System.out.println("____________________________________________________________________________");
        System.out.println("|                                                                           |");
        System.out.println("|                                     Login                                 |");
        System.out.println("|___________________________________________________________________________|");
        System.out.print("\n\n");
    }

    public static void menuAdmin(){
        System.out.println("\n\n\n\n\n\n\n\n");
        System.out.println("____________________________________________________________________________");
        System.out.println("|                                                                           |");
        System.out.println("|                             Menu Administrador                            |");
        System.out.println("|___________________________________________________________________________|");
        System.out.println("|                                                                           |");
        System.out.println("|        1. Adicionar Campeonato                                            |");
        System.out.println("|        2. Adicionar Circuito                                              |");
        System.out.println("|        3. Adicionar Carro                                                 |");
        System.out.println("|        4. Adicionar Piloto                                                |");
        System.out.println("|        0. Voltar ao Menu principal                                        |");
        System.out.println("|___________________________________________________________________________|");
        System.out.print("Digite a sua opção\n>");
    }

    public static void adicionarCampeonato(){
        System.out.println("\n\n\n\n\n\n\n\n");
        System.out.println("____________________________________________________________________________");
        System.out.println("|                                                                           |");
        System.out.println("|                            Adicionar Campeonato                           |");
        System.out.println("|___________________________________________________________________________|");
        System.out.print("-Escolha um nome\n>");
    }

    public static void adicionarCircuito(){
        System.out.println("\n\n\n\n\n\n\n\n");
        System.out.println("____________________________________________________________________________");
        System.out.println("|                                                                           |");
        System.out.println("|                             Adicionar Circuito                            |");
        System.out.println("|___________________________________________________________________________|");
        System.out.print("Escolha um nome\n>");
    }

    public static void adicionarPiloto(){
        System.out.println("\n\n\n\n\n\n\n\n");
        System.out.println("____________________________________________________________________________");
        System.out.println("|                                                                           |");
        System.out.println("|                              Adicionar Piloto                             |");
        System.out.println("|___________________________________________________________________________|");
        System.out.print("Escolha um nome\n>");
    }

    public static void adicionarCarro(){
        System.out.println("\n\n\n\n\n\n\n\n");
        System.out.println("____________________________________________________________________________");
        System.out.println("|                                                                           |");
        System.out.println("|                              Adicionar Carro                              |");
        System.out.println("|___________________________________________________________________________|");
        System.out.println("|                                                                           |");
        System.out.println("|        1. Classe 1: cilindrada de 6000cm3                                 |");
        System.out.println("|        2. Classe 2: cilindradas entre 3000cm3 e 5000cm3                   |");
        System.out.println("|        3. Classe Grande Turismo: entre 2000cm3 e 4000cm3                  |");
        System.out.println("|        4. Stock Cars: 2500cm3 de cilindrada                               |");
        System.out.println("|        0. Voltar ao Menu principal                                        |");
        System.out.println("|___________________________________________________________________________|");
        System.out.print("Digite a sua opção\n>");
    }

    public static void menuJogador(){
        System.out.println("\n\n\n\n\n\n\n\n");
        System.out.println("____________________________________________________________________________");
        System.out.println("|                                                                           |");
        System.out.println("|                                Menu Jogador                               |");
        System.out.println("|___________________________________________________________________________|");
        System.out.print("\n\n");
        System.out.print("Indique o numero de jogadores\n>");
    }

    public static void listaCampeonato(Collection<Campeonato> lc){
        System.out.println("\n\n\n\n\n\n\n\n");
        System.out.println("____________________________________________________________________________");
        System.out.println("|                                                                           |");
        System.out.println("|                            Lista de Campeonatos                           |");
        System.out.println("|___________________________________________________________________________|");
        int i = 1;
        for(Campeonato c : lc){
            System.out.println("----------"+i+"-"+c);
            i++;
        }
        System.out.print("Escolha um campeonato indicando o seu identificador ou 0 para voltar ao menu anterior.\n>");

    }

    public static void listaCarro(Collection<Carro> lc, int id){
        System.out.println("\n\n\n\n\n\n\n\n");
        System.out.println("____________________________________________________________________________");
        System.out.println("|                                                                           |");
        System.out.println("|                               Lista de Carros                             |");
        System.out.println("|___________________________________________________________________________|");
        int i = 1;
        for(Carro c : lc){
            System.out.println("----------"+i+"-"+c);
            i++;
        }
        System.out.print("Jogador "+id+" escolha um carro indicando o seu identificador.\n>");
    }

    public static void listaPiloto(Collection<Piloto> lp,int id){
        System.out.println("\n\n\n\n\n\n\n\n");
        System.out.println("____________________________________________________________________________");
        System.out.println("|                                                                           |");
        System.out.println("|                               Lista de Pilotos                            |");
        System.out.println("|___________________________________________________________________________|");
        int i = 1;
        for(Piloto p : lp){
            System.out.println("----------"+i+"-"+p);
            i++;
        }
        System.out.print("Jogador "+id+" escolha um piloto indicando o seu identificador.\n>");
    }

    public static void listaCircuitos(Collection<Circuito> lp){
        System.out.println("\n\n\n\n\n\n\n\n");
        System.out.println("____________________________________________________________________________");
        System.out.println("|                                                                           |");
        System.out.println("|                              Lista de Circuitos                           |");
        System.out.println("|___________________________________________________________________________|");
        for(Circuito p : lp){
            System.out.println(p);
        }
        View.print("Digite os nomes dos circuitos escolhidos separados por um espaço\n>");
    }

    public static void registarJogador(){
        System.out.println("\n\n\n\n\n\n\n\n");
        System.out.println("____________________________________________________________________________");
        System.out.println("|                                                                           |");
        System.out.println("|                              Registar Jogador                             |");
        System.out.println("|___________________________________________________________________________|");

    }

    public static void print(String s){
        System.out.print(s);
    }

}
