package Data;

import java.sql.*;
import java.util.*;
import RacingManagerLN.Campeonatos.Piloto;

public class PilotoDAO implements Map<String, Piloto> {
    private static PilotoDAO singleton = null;

    PilotoDAO(){
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            String sql = "CREATE TABLE IF NOT EXISTS pilotos (" +
                    "nome VARCHAR(45) NOT NULL," +
                    "cts DOUBLE NOT NULL," +
                    "sva DOUBLE NOT NULL," +
                    "PRIMARY KEY (nome)"+
                    ");"; //ENGINE=InnoDB DEFAULT CHARSET=utf8
            stm.executeUpdate(sql);
        } catch (SQLException e) {
            // Erro a criar tabela...
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
    }

    public static PilotoDAO getInstance() {
        if (PilotoDAO.singleton == null) {
            PilotoDAO.singleton = new PilotoDAO();
        }
        return PilotoDAO.singleton;
    }

    @Override
    public int size() {
        int i = 0;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();
             ResultSet rs = stm.executeQuery("SELECT count(*) FROM pilotos")) {
            if (rs.next()) {
                i = rs.getInt(1);
            }
        } catch (Exception e) {
            // Erro a criar tabela...
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return i;
    }

    @Override
    public boolean isEmpty() {
        return this.size() == 0;
    }

    @Override
    public boolean containsKey(Object key) {
        boolean r;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();
             ResultSet rs = stm.executeQuery("SELECT nome FROM pilotos WHERE nome='" + key + "'")) {
            r = rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return r;
    }

    @Override
    public boolean containsValue(Object value) {
        Piloto p = (Piloto) value;
        boolean r;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()){
            int i;
            ResultSet rs = stm.executeQuery("SELECT * FROM pilotos WHERE " +
                    "nome = \"" + p.getNome() +
                    "\"&& cts = " + p.getCts() +
                    "&& sva = " + p.getSva() +";");

            r = rs.next();
        }catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return r;
    }

    @Override
    public Piloto get(Object key) {
        Piloto p = null;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {

            ResultSet rs = stm.executeQuery("SELECT * FROM pilotos WHERE nome='"+ key +"'");

            if (rs.next()) {   // A chave existe na tabela
                p = new Piloto(rs.getString("nome"),
                        rs.getDouble("cts"),
                        rs.getDouble("sva"));
            }
        } catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }

        return p;
    }

    @Override
    public Piloto put(String key, Piloto p) {
        Piloto res = null;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {

            ResultSet rs = stm.executeQuery("SELECT * FROM pilotos WHERE nome='"+key+"'");

            if (rs.next()) {
                res = new Piloto(rs.getString("nome"),
                        rs.getDouble("cts"),
                        rs.getDouble("sva"));

                stm.executeUpdate("UPDATE pilotos SET " +
                        "nome = '" + p.getNome() +
                        "', versao = " + p.getCts() +
                        ", pontos = " + p.getSva() +
                        " WHERE nome = '" + key + "';");

            } else {
                stm.executeUpdate("INSERT INTO pilotos (nome,cts,sva) VALUES ('" +
                        p.getNome() + "'," +
                        p.getCts() + "," +
                        p.getSva() +");" );
            }
        } catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return res;
    }

    @Override
    public Piloto remove(Object key) {
        Piloto p = this.get(key);

        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            stm.executeUpdate("DELETE FROM pilotos WHERE nome='"+key+"'");
        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return p;
    }

    @Override
    public void putAll(Map<? extends String, ? extends Piloto> pilotos) {
        for(Piloto p : pilotos.values()) {
            this.put(p.getNome(), p);
        }
    }

    @Override
    public void clear() {
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            stm.executeUpdate("TRUNCATE pilotos");
        } catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
    }

    @Override
    public Set<String> keySet() {
        Set<String> col = new HashSet<>();

        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();

             ResultSet rs = stm.executeQuery("SELECT nome FROM pilotos")) {
            while (rs.next()) {
                col.add(rs.getString("nome"));
            }
        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return col;
    }

    @Override
    public Collection<Piloto> values() {
        Collection<Piloto> col = new HashSet<>();
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();

             ResultSet rs = stm.executeQuery("SELECT nome FROM pilotos")) {
            while (rs.next()) {
                col.add(this.get(rs.getString("nome")));
            }
        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return col;
    }

    @Override
    public Set<Entry<String, Piloto>> entrySet() {
        Set<Map.Entry<String, Piloto>> res = new HashSet<>();

        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {

            ResultSet rs = stm.executeQuery("SELECT nome FROM pilotos");
            while (rs.next()) {
                String username = rs.getString("nome");
                Piloto p = get(username);
                AbstractMap.SimpleEntry e = new AbstractMap.SimpleEntry(username, p);
                res.add(e);
            }

        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return res;
    }
}
