package Data;

import java.sql.*;
import java.util.*;
import RacingManagerLN.Utilizadores.Administrador;

public class AdministradorDAO implements Map<String, Administrador> {
    private static AdministradorDAO singleton = null;

    AdministradorDAO(){
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            String sql = "CREATE TABLE IF NOT EXISTS administrador (" +
                    "nome VARCHAR(45) NOT NULL," +
                    "password VARCHAR(45) NOT NULL," +
                    "logged BOOLEAN NOT NULL," +
                    "PRIMARY KEY (nome)"+
                    ");"; //ENGINE=InnoDB DEFAULT CHARSET=utf8
            stm.executeUpdate(sql);
        } catch (SQLException e) {
            // Erro a criar tabela...
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
    }

    public static AdministradorDAO getInstance() {
        if (AdministradorDAO.singleton == null) {
            AdministradorDAO.singleton = new AdministradorDAO();
        }
        return AdministradorDAO.singleton;
    }

    @Override
    public int size() {
        int i = 0;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();
             ResultSet rs = stm.executeQuery("SELECT count(*) FROM administrador")) {
            if (rs.next()) {
                i = rs.getInt(1);
            }
        } catch (Exception e) {
            // Erro a criar tabela...
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return i;
    }

    @Override
    public boolean isEmpty() {
        return this.size() == 0;
    }

    @Override
    public boolean containsKey(Object key) {
        boolean r;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();
             ResultSet rs = stm.executeQuery("SELECT nome FROM administrador WHERE nome='" + key + "'")) {
            r = rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return r;
    }

    @Override
    public boolean containsValue(Object value) {
        Administrador a = (Administrador) value;
        boolean r;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()){

            ResultSet rs = stm.executeQuery("SELECT * FROM administrador WHERE " +
                    "nome = \"" + a.getNome() +
                    "\"&& password = \"" + a.getPassword() + "\";");

            r = rs.next();
        }catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return r;
    }

    @Override
    public Administrador get(Object key) {
        Administrador a = null;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {

            ResultSet rs = stm.executeQuery("SELECT * FROM administrador WHERE nome='"+ key +"'");

            if (rs.next()) {   // A chave existe na tabela
                a = new Administrador(rs.getString("nome"), rs.getString("password"));
            }
        } catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }

        return a;
    }

    @Override
    public Administrador put(String key, Administrador a) {
        Administrador res = null;

        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {

            ResultSet rs = stm.executeQuery("SELECT * FROM administrador WHERE nome='"+key+"'");

            if (rs.next()) {
                res = new Administrador(rs.getString("Password"), rs.getString("Nome"));

                stm.executeUpdate("UPDATE administrador SET " +
                        "nome = '" + a.getNome() +
                        "', password = '" + a.getPassword() +
                        "' WHERE nome = '" + key + "';");

            } else {
                stm.executeUpdate("INSERT INTO administrador (nome,password) VALUES ('" +
                        a.getNome() + "','" +
                        a.getPassword() + "');" );
            }
        } catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return res;
    }

    @Override
    public Administrador remove(Object key) {
        Administrador a = this.get(key);

        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            stm.executeUpdate("DELETE FROM administrador WHERE nome='"+key+"'");
        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return a;
    }

    @Override
    public void putAll(Map<? extends String, ? extends Administrador> administradores) {
        for(Administrador a : administradores.values()) {
            this.put(a.getNome(), a);
        }
    }

    @Override
    public void clear() {
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            stm.executeUpdate("TRUNCATE administrador");
        } catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
    }

    @Override
    public Set<String> keySet() {
        Set<String> col = new HashSet<>();

        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();

             ResultSet rs = stm.executeQuery("SELECT nome FROM administrador")) {
            while (rs.next()) {
                col.add(rs.getString("nome"));
            }
        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return col;
    }

    @Override
    public Collection<Administrador> values() {
        Collection<Administrador> col = new HashSet<>();
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();

             ResultSet rs = stm.executeQuery("SELECT nome FROM administrador")) {
            while (rs.next()) {
                col.add(this.get(rs.getString("nome")));
            }
        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return col;
    }

    @Override
    public Set<Entry<String, Administrador>> entrySet() {
        Set<Map.Entry<String, Administrador>> res = new HashSet<>();

        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {

            ResultSet rs = stm.executeQuery("SELECT nome FROM administrador");
            while (rs.next()) {
                String username = rs.getString("nome");
                Administrador a = get(username);
                AbstractMap.SimpleEntry e = new AbstractMap.SimpleEntry(username, a);
                res.add(e);
            }

        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return res;
    }

    public void logIn (Object key) {
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            stm.executeUpdate("UPDATE administrador SET " +
                    "Logged = TRUE " +
                    "WHERE Username = '" + key + "';" );

        } catch (Exception e) {
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
    }

    public void logOut (Object key) {
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            stm.executeUpdate("UPDATE administrador SET " +
                    "Logged = FALSE " +
                    "WHERE nome = '" + key + "';" );

        } catch (Exception e) {
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
    }
}
