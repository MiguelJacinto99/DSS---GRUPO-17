package Data;

import java.sql.*;
import java.util.*;
import RacingManagerLN.Corridas.Circuito;

public class CircuitoDAO implements Map<String, Circuito> {
    private static CircuitoDAO singleton = null;

    CircuitoDAO(){
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            String sql = "CREATE TABLE IF NOT EXISTS carro (" +
                    "nome VARCHAR(45) NOT NULL," +
                    "distancia INT NOT NULL," +
                    "voltas INT NOT NULL," +
                    "tempoDesvio INT NOT NULL," +
                    "tempoBox INT NOT NULL," +
                    "caminhos VARCHAR(100) NOT NULL," +
                    "dificuldades VARCHAR(100) NOT NULL," +
                    "PRIMARY KEY (nome)"+
                    ");"; //ENGINE=InnoDB DEFAULT CHARSET=utf8
            stm.executeUpdate(sql);
        } catch (SQLException e) {
            // Erro a criar tabela...
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
    }

    public static CircuitoDAO getInstance() {
        if (CircuitoDAO.singleton == null) {
            CircuitoDAO.singleton = new CircuitoDAO();
        }
        return CircuitoDAO.singleton;
    }

    @Override
    public int size() {
        int i = 0;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();
             ResultSet rs = stm.executeQuery("SELECT count(*) FROM circuito")) {
            if (rs.next()) {
                i = rs.getInt(1);
            }
        } catch (Exception e) {
            // Erro a criar tabela...
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return i;
    }

    @Override
    public boolean isEmpty() {
        return this.size() == 0;
    }

    @Override
    public boolean containsKey(Object key) {
        boolean r;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();
             ResultSet rs = stm.executeQuery("SELECT nome FROM circuito WHERE nome='" + key + "'")) {
            r = rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return r;
    }

    @Override
    public boolean containsValue(Object value) {
        Circuito c = (Circuito) value;
        boolean r;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()){
            int i;
            ResultSet rs = stm.executeQuery("SELECT * FROM circuito WHERE " +
                    "nome = \"" + c.getNome() +
                    "\"&& distancia = " + c.getDistancia() +
                    "&& voltas = " + c.getVoltas() +
                    "&& tempoDesvio = " + c.getTempoDesvio() +
                    "&& tempoBox = " + c.getTempoBox() +
                    "&& caminhos = '" + c.caminhoToString() +
                    "'&& dificuldades = '" + c.dificuldadeToString() +"';");

            r = rs.next();
        }catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return r;
    }

    @Override
    public Circuito get(Object key) {
        Circuito c = null;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {

            ResultSet rs = stm.executeQuery("SELECT * FROM circuito WHERE nome='"+ key +"'");

            if (rs.next()) {   // A chave existe na tabela
                c = new Circuito(rs.getString("nome"),
                        rs.getInt("distancia"),
                        rs.getInt("voltas"),
                        rs.getInt("tempoDesvio"),
                        rs.getInt("tempoBox"),
                        rs.getString("caminhos"),
                        rs.getString("dificuldades"));
            }
        } catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }

        return c;
    }

    @Override
    public Circuito put(String key, Circuito c) {
        Circuito res = null;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {

            ResultSet rs = stm.executeQuery("SELECT * FROM circuito WHERE nome='"+key+"'");

            if (rs.next()) {
                res = new Circuito(rs.getString("nome"),
                        rs.getInt("distancia"),
                        rs.getInt("voltas"),
                        rs.getInt("tempoDesvio"),
                        rs.getInt("tempoBox"),
                        rs.getString("caminhos"),
                        rs.getString("dificuldades"));


                stm.executeUpdate("UPDATE circuito SET " +
                        "nome = '" + c.getNome() +
                        "', distancia = " + c.getDistancia() +
                        ", voltas = " + c.getVoltas() +
                        ", tempoDesvio = " + c.getTempoDesvio() +
                        ", tempoBox = " + c.getTempoBox() +
                        ", caminhos = '" + c.caminhoToString() +
                        "', dificuldades = '" + c.dificuldadeToString() +
                        "' WHERE nome = '" + key + "';");

            } else {
                stm.executeUpdate("INSERT INTO circuito (nome,distancia,voltas,tempoDesvio,tempoBox,caminhos,dificuldades) VALUES ('" +
                        c.getNome() + "'," +
                        c.getDistancia() + "," +
                        c.getVoltas() + "," +
                        c.getTempoDesvio() + "," +
                        c.getTempoBox() + ",'" +
                        c.caminhoToString() + "','" +
                        c.dificuldadeToString() +"');");
            }
        } catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return res;
    }

    @Override
    public Circuito remove(Object key) {
        Circuito c = this.get(key);

        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            stm.executeUpdate("DELETE FROM circuito WHERE nome='"+key+"'");
        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return c;
    }

    @Override
    public void putAll(Map<? extends String, ? extends Circuito> circuitos) {
        for(Circuito c : circuitos.values()) {
            this.put(c.getNome(), c);
        }
    }

    @Override
    public void clear() {
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            stm.executeUpdate("TRUNCATE circuito");
        } catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
    }

    @Override
    public Set<String> keySet() {
        Set<String> col = new HashSet<>();

        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();

             ResultSet rs = stm.executeQuery("SELECT nome FROM circuito")) {
            while (rs.next()) {
                col.add(rs.getString("nome"));
            }
        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return col;
    }

    @Override
    public Collection<Circuito> values() {
        Collection<Circuito> col = new HashSet<>();
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();

             ResultSet rs = stm.executeQuery("SELECT nome FROM circuito")) {
            while (rs.next()) {
                col.add(this.get(rs.getString("nome")));
            }
        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return col;
    }

    @Override
    public Set<Entry<String, Circuito>> entrySet() {
        Set<Map.Entry<String, Circuito>> res = new HashSet<>();

        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {

            ResultSet rs = stm.executeQuery("SELECT nome FROM circuito");
            while (rs.next()) {
                String username = rs.getString("nome");
                Circuito c = get(username);
                AbstractMap.SimpleEntry e = new AbstractMap.SimpleEntry(username, c);
                res.add(e);
            }

        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return res;
    }
}
