package Data;

import java.sql.*;
import java.util.*;
import RacingManagerLN.Campeonatos.Campeonato;
import RacingManagerLN.Corridas.Corrida;

public class CampeonatoDAO implements Map<String, Campeonato> {
    private static CampeonatoDAO singleton = null;

    CampeonatoDAO(){
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            String sql = "CREATE TABLE IF NOT EXISTS campeonato (" +
                    "nome VARCHAR(45) NOT NULL," +
                    "circuitos VARCHAR(150) NOT NULL," +
                    "PRIMARY KEY (nome)"+
                    ");"; //ENGINE=InnoDB DEFAULT CHARSET=utf8
            stm.executeUpdate(sql);
        } catch (SQLException e) {
            // Erro a criar tabela...
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
    }

    public static CampeonatoDAO getInstance() {
        if (CampeonatoDAO.singleton == null) {
            CampeonatoDAO.singleton = new CampeonatoDAO();
        }
        return CampeonatoDAO.singleton;
    }

    @Override
    public int size() {
        int i = 0;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();
             ResultSet rs = stm.executeQuery("SELECT count(*) FROM campeonato")) {
            if (rs.next()) {
                i = rs.getInt(1);
            }
        } catch (Exception e) {
            // Erro a criar tabela...
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return i;
    }

    @Override
    public boolean isEmpty() {
        return this.size() == 0;
    }

    @Override
    public boolean containsKey(Object key) {
        boolean r;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();
             ResultSet rs = stm.executeQuery("SELECT nome FROM campeonato WHERE nome='" + key + "'")) {
            r = rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return r;
    }

    @Override
    public boolean containsValue(Object value) {
        Campeonato c = (Campeonato) value;
        boolean r;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()){
            int i;
            ResultSet rs = stm.executeQuery("SELECT * FROM campeonato WHERE " +
                    "nome = \"" + c.getNome() +
                    "\"&& circuitos = \"" + c.corridasToString() +"\";");

            r = rs.next();
        }catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return r;
    }

    @Override
    public Campeonato get(Object key) {
        Campeonato c = null;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {

            ResultSet rs = stm.executeQuery("SELECT * FROM campeonato WHERE nome='"+ key +"'");

            if (rs.next()) {   // A chave existe na tabela
                String nome = rs.getString("nome");
                String circuitos = rs.getString("circuitos");
                CircuitoDAO cd = new CircuitoDAO();
                String[] split = circuitos.split(";");
                List<Corrida> lc = new ArrayList<>();
                for(String s : split){
                    String[] split2 = s.split(" ");
                    Corrida corrida = new Corrida(cd.get(split2[0]),Integer.parseInt(split2[1]));
                    lc.add(corrida);
                }
                c = new Campeonato(nome,lc);
            }
        } catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }

        return c;
    }

    @Override
    public Campeonato put(String key, Campeonato c) {
        Campeonato res = null;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {

            ResultSet rs = stm.executeQuery("SELECT * FROM campeonato WHERE nome='"+key+"'");

            if (rs.next()) {
                String nome = rs.getString("nome");
                String circuitos = rs.getString("circuitos");
                CircuitoDAO cd = new CircuitoDAO();
                String[] split = circuitos.split(";");
                List<Corrida> lc = new ArrayList<>();
                for(String s : split){
                    String[] split2 = s.split(" ");
                    Corrida corrida = new Corrida(cd.get(split2[0]),Integer.parseInt(split2[1]));
                    lc.add(corrida);
                }
                res = new Campeonato(nome,lc);

                String exec = "UPDATE campeonato SET nome = '" + c.getNome() + "'";
                String circ = "";
                for(Corrida corrida : c.getCorridas()){
                    circ += corrida.getCircuito().getNome()+" "+corrida.getClima()+";";
                }
                exec += ", circuitos = '"+circ+"' WHERE nome = '" + key + "';";

                stm.executeUpdate(exec);

            } else {

                String exec = "INSERT INTO campeonato (nome,circuitos) VALUES ('" + c.getNome() + "'";
                String circ = "";
                for(Corrida corrida : c.getCorridas()){
                    circ += corrida.getCircuito().getNome()+" "+corrida.getClima()+";";
                }
                exec += ",'"+circ+"');";
                stm.executeUpdate(exec);
            }
        } catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return res;
    }

    @Override
    public Campeonato remove(Object key) {
        Campeonato c = this.get(key);

        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            stm.executeUpdate("DELETE FROM campeonato WHERE nome='"+key+"'");
        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return c;
    }

    @Override
    public void putAll(Map<? extends String, ? extends Campeonato> campeonatos) {
        for(Campeonato c : campeonatos.values()) {
            this.put(c.getNome(), c);
        }
    }

    @Override
    public void clear() {
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            stm.executeUpdate("TRUNCATE campeonato");
        } catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
    }

    @Override
    public Set<String> keySet() {
        Set<String> col = new HashSet<>();

        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();

             ResultSet rs = stm.executeQuery("SELECT nome FROM campeonato")) {
            while (rs.next()) {
                col.add(rs.getString("nome"));
            }
        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return col;
    }

    @Override
    public Collection<Campeonato> values() {
        Collection<Campeonato> col = new HashSet<>();
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();

             ResultSet rs = stm.executeQuery("SELECT nome FROM campeonato")) {
            while (rs.next()) {
                col.add(this.get(rs.getString("nome")));
            }
        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return col;
    }

    @Override
    public Set<Entry<String, Campeonato>> entrySet() {
        Set<Map.Entry<String, Campeonato>> res = new HashSet<>();

        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {

            ResultSet rs = stm.executeQuery("SELECT nome FROM campeonato");
            while (rs.next()) {
                String username = rs.getString("nome");
                Campeonato c = get(username);
                AbstractMap.SimpleEntry e = new AbstractMap.SimpleEntry(username, c);
                res.add(e);
            }

        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return res;
    }
}
