package Data;

public class DAOconfig {
    static final String USERNAME = "root";                       // Actualizar
    static final String PASSWORD = "dss123";                       // Actualizar
    private static final String DATABASE = "mydb";          // Actualizar
    private static final String DRIVER = "jdbc:mysql";        // Usar para MySQL
    static final String URL = DRIVER+"://localhost:3306/"+DATABASE+"?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
}
