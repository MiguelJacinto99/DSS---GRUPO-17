package Data;

import java.sql.*;
import java.util.*;
import RacingManagerLN.Utilizadores.Jogador;

public class JogadorDAO implements Map<String, Jogador> {
    private static JogadorDAO singleton = null;

    JogadorDAO(){
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            String sql = "CREATE TABLE IF NOT EXISTS administrador (" +
                    "nome VARCHAR(45) NOT NULL," +
                    "password VARCHAR(45) NOT NULL," +
                    "versao BOOLEAN NOT NULL," +
                    "pontos INT NOT NULL," +
                    "logged BOOLEAN NOT NULL," +
                    "PRIMARY KEY (nome)"+
                    ");"; //ENGINE=InnoDB DEFAULT CHARSET=utf8
            stm.executeUpdate(sql);
        } catch (SQLException e) {
            // Erro a criar tabela...
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
    }

    public static JogadorDAO getInstance() {
        if (JogadorDAO.singleton == null) {
            JogadorDAO.singleton = new JogadorDAO();
        }
        return JogadorDAO.singleton;
    }

    @Override
    public int size() {
        int i = 0;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();
             ResultSet rs = stm.executeQuery("SELECT count(*) FROM jogador")) {
            if (rs.next()) {
                i = rs.getInt(1);
            }
        } catch (Exception e) {
            // Erro a criar tabela...
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return i;
    }

    @Override
    public boolean isEmpty() {
        return this.size() == 0;
    }

    @Override
    public boolean containsKey(Object key) {
        boolean r;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();
             ResultSet rs = stm.executeQuery("SELECT nome FROM jogador WHERE nome='" + key + "'")) {
            r = rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return r;
    }

    @Override
    public boolean containsValue(Object value) {
        Jogador j = (Jogador) value;
        boolean r;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()){
            int i;
            if(j.isVersao()){
                i = 1;
            }else{
                i = 0;
            }
            ResultSet rs = stm.executeQuery("SELECT * FROM jogador WHERE " +
                    "nome = \"" + j.getNome() +
                    "\"&& password = \"" + j.getPassword() +
                    "\"&& versao = " + i +
                    "&& pontos = " + j.getPontos() + ";");

            r = rs.next();
        }catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return r;
    }

    @Override
    public Jogador get(Object key) {
        Jogador j = null;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {

            ResultSet rs = stm.executeQuery("SELECT * FROM jogador WHERE nome='"+ key +"'");

            if (rs.next()) {   // A chave existe na tabela
                j = new Jogador(rs.getString("nome"),
                        rs.getString("password"),
                        rs.getBoolean("versao"),
                        rs.getInt("pontos"),
                        rs.getBoolean("logged"));
            }
        } catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }

        return j;
    }

    @Override
    public Jogador put(String key, Jogador j) {
        Jogador res = null;
        int i;
        if(j.isVersao()){
            i = 1;
        }else{
            i = 0;
        }
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {

            ResultSet rs = stm.executeQuery("SELECT * FROM jogador WHERE nome='"+key+"'");

            if (rs.next()) {
                res = new Jogador(rs.getString("nome"),
                        rs.getString("password"),
                        rs.getBoolean("versao"),
                        rs.getInt("pontos"));
                stm.executeUpdate("UPDATE jogador SET " +
                        "nome = '" + j.getNome() +
                        "', password = '" + j.getPassword() +
                        "', versao = " + i +
                        ", pontos = " + j.getPontos() +
                        " WHERE nome = '" + key + "';");

            } else {
                stm.executeUpdate("INSERT INTO jogador (nome,password,versao,pontos,logged) VALUES ('" +
                        j.getNome() + "','" +
                        j.getPassword() + "'," +
                        i + "," +
                        j.getPontos() + "," +
                        j.isLogged() +");" );
            }
        } catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return res;
    }

    @Override
    public Jogador remove(Object key) {
        Jogador j = this.get(key);

        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            stm.executeUpdate("DELETE FROM jogador WHERE nome='"+key+"'");
        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return j;
    }

    @Override
    public void putAll(Map<? extends String, ? extends Jogador> jogadores) {
        for(Jogador j : jogadores.values()) {
            this.put(j.getNome(), j);
        }
    }

    @Override
    public void clear() {
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            stm.executeUpdate("TRUNCATE jogador");
        } catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
    }

    @Override
    public Set<String> keySet() {
        Set<String> col = new HashSet<>();

        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();

             ResultSet rs = stm.executeQuery("SELECT nome FROM jogador")) {
            while (rs.next()) {
                col.add(rs.getString("nome"));
            }
        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return col;
    }

    @Override
    public Collection<Jogador> values() {
        Collection<Jogador> col = new HashSet<>();
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();

             ResultSet rs = stm.executeQuery("SELECT nome FROM jogador")) {
            while (rs.next()) {
                col.add(this.get(rs.getString("nome")));
            }
        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return col;
    }

    @Override
    public Set<Entry<String, Jogador>> entrySet() {
        Set<Map.Entry<String, Jogador>> res = new HashSet<>();

        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {

            ResultSet rs = stm.executeQuery("SELECT nome FROM jogador");
            while (rs.next()) {
                String username = rs.getString("nome");
                Jogador a = get(username);
                AbstractMap.SimpleEntry e = new AbstractMap.SimpleEntry(username, a);
                res.add(e);
            }

        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return res;
    }

    public void logIn (Object key) {
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            stm.executeUpdate("UPDATE jogador SET " +
                    "logged = TRUE " +
                    "WHERE nome = '" + key + "';" );

        } catch (Exception e) {
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
    }

    public void logOut (Object key) {
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            stm.executeUpdate("UPDATE jogador SET " +
                    "logged = FALSE " +
                    "WHERE nome = '" + key + "';" );

        } catch (Exception e) {
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
    }
}
