package Data;

import java.sql.*;
import java.util.*;
import RacingManagerLN.Campeonatos.*;

public class CarroDAO implements Map<String, Carro> {
    private static CarroDAO singleton = null;

    CarroDAO(){
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            String sql = "CREATE TABLE IF NOT EXISTS carro (" +
                    "class VARCHAR(45) NOT NULL," +
                    "marca VARCHAR(45) NOT NULL," +
                    "modelo VARCHAR(45) NOT NULL," +
                    "cilindrada INT NOT NULL," +
                    "potencia INT NOT NULL," +
                    "pac DOUBLE NOT NULL," +
                    "motor INT NOT NULL," +
                    "fiabilidade INT NOT NULL," +
                    "potenciaH INT," +
                    "taxa DOUBLE," +
                    "PRIMARY KEY (modelo)"+
                    ");"; //ENGINE=InnoDB DEFAULT CHARSET=utf8
            stm.executeUpdate(sql);
        } catch (SQLException e) {
            // Erro a criar tabela...
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
    }

    public static CarroDAO getInstance() {
        if (CarroDAO.singleton == null) {
            CarroDAO.singleton = new CarroDAO();
        }
        return CarroDAO.singleton;
    }

    @Override
    public int size() {
        int i = 0;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();
             ResultSet rs = stm.executeQuery("SELECT count(*) FROM carro")) {
            if (rs.next()) {
                i = rs.getInt(1);
            }
        } catch (Exception e) {
            // Erro a criar tabela...
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return i;
    }

    @Override
    public boolean isEmpty() {
        return this.size() == 0;
    }

    @Override
    public boolean containsKey(Object key) {
        boolean r;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();
             ResultSet rs = stm.executeQuery("SELECT modelo FROM carro WHERE modelo='" + key + "'")) {
            r = rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return r;
    }

    @Override
    public boolean containsValue(Object value) {
        Carro c = (Carro) value;
        boolean r;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()){
            ResultSet rs = stm.executeQuery("SELECT * FROM carro WHERE " +
                    "marca = \"" + c.getMarca() +
                    "\"&& modelo = \"" + c.getModelo() +
                    "\"&& cilindrada = " + c.getCilindrada() +
                    "&& potencia = " + c.getPotencia() +
                    "&& pac = " + c.getPac() +
                    "&& motor = " + c.getMotor() +
                    "&& fiabilidade = " + c.getFiabilidade() +";");

            r = rs.next();
        }catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return r;
    }

    @Override
    public Carro get(Object key) {
        Carro c = null;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {

            ResultSet rs = stm.executeQuery("SELECT * FROM carro WHERE modelo='"+ key +"'");

            if (rs.next()) {   // A chave existe na tabela
                String tipo = rs.getString("class");
                switch (tipo){
                    case "PC1":
                        c = new PC1(rs.getString("marca"), rs.getString("modelo"), rs.getInt("cilindrada"),
                                rs.getInt("potencia"), rs.getDouble("pac"), rs.getInt("motor"), rs.getInt("fiabilidade"));
                        break;
                    case "PC1H":
                        c = new PC1H(rs.getString("marca"), rs.getString("modelo"), rs.getInt("cilindrada"),
                                rs.getInt("potencia"), rs.getDouble("pac"), rs.getInt("motor"), rs.getInt("fiabilidade"),
                                rs.getInt("potenciaH"));
                        break;
                    case "PC2":
                        c = new PC2(rs.getString("marca"), rs.getString("modelo"), rs.getInt("cilindrada"),
                                rs.getInt("potencia"), rs.getDouble("pac"), rs.getInt("motor"), rs.getInt("fiabilidade"));
                        break;
                    case "PC2H":
                        c = new PC2H(rs.getString("marca"), rs.getString("modelo"), rs.getInt("cilindrada"),
                                rs.getInt("potencia"), rs.getDouble("pac"), rs.getInt("motor"), rs.getInt("fiabilidade"),
                                rs.getInt("potenciaH"));
                        break;
                    case "GT":
                        c = new GT(rs.getString("marca"), rs.getString("modelo"), rs.getInt("cilindrada"),
                                rs.getInt("potencia"), rs.getDouble("pac"), rs.getInt("motor"), rs.getInt("fiabilidade"),
                                rs.getDouble("taxa"));
                        break;
                    case "GTH":
                        c = new GTH(rs.getString("marca"), rs.getString("modelo"), rs.getInt("cilindrada"),
                                rs.getInt("potencia"), rs.getDouble("pac"), rs.getInt("motor"), rs.getInt("fiabilidade"),
                                rs.getInt("potenciaH"), rs.getDouble("taxa"));
                        break;
                    case "SC":
                        c = new SC(rs.getString("marca"), rs.getString("modelo"), rs.getInt("cilindrada"),
                                rs.getInt("potencia"), rs.getDouble("pac"), rs.getInt("motor"), rs.getInt("fiabilidade"));
                        break;
                }
            }
        } catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }

        return c;
    }

    @Override
    public Carro put(String key, Carro c) {
        Carro res = null;
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {

            ResultSet rs = stm.executeQuery("SELECT * FROM carro WHERE modelo='"+key+"'");
            boolean hibrido = !(c.getPotenciaH()==0);
            boolean temTaxa = !(c.getTaxa()==0);
            if (rs.next()) {
                String tipo = rs.getString("class");
                switch (tipo){
                    case "PC1":
                        res = new PC1(rs.getString("marca"), rs.getString("modelo"), rs.getInt("cilindrada"),
                                rs.getInt("potencia"), rs.getDouble("pac"), rs.getInt("motor"), rs.getInt("fiabilidade"));
                        break;
                    case "PC1H":
                        res = new PC1H(rs.getString("marca"), rs.getString("modelo"), rs.getInt("cilindrada"),
                                rs.getInt("potencia"), rs.getDouble("pac"), rs.getInt("motor"), rs.getInt("fiabilidade"),
                                rs.getInt("potenciaH"));
                        break;
                    case "PC2":
                        res = new PC2(rs.getString("marca"), rs.getString("modelo"), rs.getInt("cilindrada"),
                                rs.getInt("potencia"), rs.getDouble("pac"), rs.getInt("motor"), rs.getInt("fiabilidade"));
                        break;
                    case "PC2H":
                        res = new PC2H(rs.getString("marca"), rs.getString("modelo"), rs.getInt("cilindrada"),
                                rs.getInt("potencia"), rs.getDouble("pac"), rs.getInt("motor"), rs.getInt("fiabilidade"),
                                rs.getInt("potenciaH"));
                        break;
                    case "GT":
                        res = new GT(rs.getString("marca"), rs.getString("modelo"), rs.getInt("cilindrada"),
                                rs.getInt("potencia"), rs.getDouble("pac"), rs.getInt("motor"), rs.getInt("fiabilidade"),
                                rs.getDouble("taxa"));
                        break;
                    case "GTH":
                        res = new GTH(rs.getString("marca"), rs.getString("modelo"), rs.getInt("cilindrada"),
                                rs.getInt("potencia"), rs.getDouble("pac"), rs.getInt("motor"), rs.getInt("fiabilidade"),
                                rs.getInt("potenciaH"), rs.getDouble("taxa"));
                        break;
                    case "SC":
                        res = new SC(rs.getString("marca"), rs.getString("modelo"), rs.getInt("cilindrada"),
                                rs.getInt("potencia"), rs.getDouble("pac"), rs.getInt("motor"), rs.getInt("fiabilidade"));
                        break;
                }
                if(hibrido && temTaxa){
                    stm.executeUpdate("UPDATE carro SET " +
                            "class = '" + c.getClass().getName() +
                            "',marca = '" + c.getMarca() +
                            "', modelo = '" + c.getModelo() +
                            "', cilindrada = " + c.getCilindrada() +
                            ", potencia = " + c.getPotencia() +
                            ", pac = " + c.getPac() +
                            ", motor = " + c.getMotor() +
                            ", fiabilidade = " + c.getFiabilidade() +
                            ", potenciaH = " + c.getPotenciaH() +
                            ", taxa = " + c.getTaxa() +
                            " WHERE modelo = '" + key + "';");

                }else if(hibrido){
                    stm.executeUpdate("UPDATE carro SET " +
                            "class = '" + c.getClass().getName() +
                            "',marca = '" + c.getMarca() +
                            "', modelo = '" + c.getModelo() +
                            "', cilindrada = " + c.getCilindrada() +
                            ", potencia = " + c.getPotencia() +
                            ", pac = " + c.getPac() +
                            ", motor = " + c.getMotor() +
                            ", fiabilidade = " + c.getFiabilidade() +
                            ", potenciaH = " + c.getPotenciaH() +
                            " WHERE modelo = '" + key + "';");

                }else if(temTaxa){
                    stm.executeUpdate("UPDATE carro SET " +
                            "class = '" + c.getClass().getName() +
                            "',marca = '" + c.getMarca() +
                            "', modelo = '" + c.getModelo() +
                            "', cilindrada = " + c.getCilindrada() +
                            ", potencia = " + c.getPotencia() +
                            ", pac = " + c.getPac() +
                            ", motor = " + c.getMotor() +
                            ", fiabilidade = " + c.getFiabilidade() +
                            ", taxa = " + c.getTaxa() +
                            " WHERE modelo = '" + key + "';");

                }else{
                    stm.executeUpdate("UPDATE carro SET " +
                            "class = '" + c.getClass().getName() +
                            "',marca = '" + c.getMarca() +
                            "', modelo = '" + c.getModelo() +
                            "', cilindrada = " + c.getCilindrada() +
                            ", potencia = " + c.getPotencia() +
                            ", pac = " + c.getPac() +
                            ", motor = " + c.getMotor() +
                            ", fiabilidade = " + c.getFiabilidade() +
                            " WHERE modelo = '" + key + "';");
                }
            } else {
                if(hibrido && temTaxa){
                    stm.executeUpdate("INSERT INTO carro (class,marca,modelo,cilindrada,potencia,pac,motor,fiabilidade,potenciaH,taxa) VALUES ('"+
                            c.getClass().getName() + "','" +
                            c.getMarca() + "','" +
                            c.getModelo() + "'," +
                            c.getCilindrada() + "," +
                            c.getPotencia() + "," +
                            c.getPac() + "," +
                            c.getMotor() + "," +
                            c.getFiabilidade() + ',' +
                            c.getPotenciaH() + "," +
                            c.getTaxa()+");");
                }else if(hibrido){
                    stm.executeUpdate("INSERT INTO carro (class,marca,modelo,cilindrada,potencia,pac,motor,fiabilidade,potenciaH) VALUES ('"+
                            c.getClass().getName() + "','" +
                            c.getMarca() + "','" +
                            c.getModelo() + "'," +
                            c.getCilindrada() + "," +
                            c.getPotencia() + "," +
                            c.getPac() + "," +
                            c.getMotor() + "," +
                            c.getPotenciaH() + "," +
                            c.getFiabilidade() + ");");
                }else if(temTaxa){
                    stm.executeUpdate("INSERT INTO carro (class,marca,modelo,cilindrada,potencia,pac,motor,fiabilidade,taxa) VALUES ('"+
                            c.getClass().getName() + "','" +
                            c.getMarca() + "','" +
                            c.getModelo() + "'," +
                            c.getCilindrada() + "," +
                            c.getPotencia() + "," +
                            c.getPac() + "," +
                            c.getMotor() + "," +
                            c.getPotenciaH() + "," +
                            c.getTaxa() + ");");
                }else{
                    stm.executeUpdate("INSERT INTO carro (class,marca,modelo,cilindrada,potencia,pac,motor,fiabilidade) VALUES ('"+
                            c.getClass().getName() + "','" +
                            c.getMarca() + "','" +
                            c.getModelo() + "'," +
                            c.getCilindrada() + "," +
                            c.getPotencia() + "," +
                            c.getPac() + "," +
                            c.getMotor() + "," +
                            c.getFiabilidade() +");");
                }
            }
        } catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return res;
    }

    @Override
    public Carro remove(Object key) {
        Carro c = this.get(key);

        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            stm.executeUpdate("DELETE FROM carro WHERE modelo='"+key+"'");
        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return c;
    }

    @Override
    public void putAll(Map<? extends String, ? extends Carro> carros) {
        for(Carro c : carros.values()) {
            this.put(c.getModelo(), c);
        }
    }

    @Override
    public void clear() {
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {
            stm.executeUpdate("TRUNCATE carro");
        } catch (SQLException e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
    }

    @Override
    public Set<String> keySet() {
        Set<String> col = new HashSet<>();

        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();

             ResultSet rs = stm.executeQuery("SELECT modelo FROM carro")) {
            while (rs.next()) {
                col.add(rs.getString("modelo"));
            }
        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return col;
    }

    @Override
    public Collection<Carro> values() {
        Collection<Carro> col = new HashSet<>();
        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement();

             ResultSet rs = stm.executeQuery("SELECT modelo FROM carro")) {
            while (rs.next()) {
                col.add(this.get(rs.getString("modelo")));
            }
        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return col;
    }

    @Override
    public Set<Entry<String, Carro>> entrySet() {
        Set<Map.Entry<String, Carro>> res = new HashSet<>();

        try (Connection conn = DriverManager.getConnection(DAOconfig.URL, DAOconfig.USERNAME, DAOconfig.PASSWORD);
             Statement stm = conn.createStatement()) {

            ResultSet rs = stm.executeQuery("SELECT modelo FROM carro");
            while (rs.next()) {
                String username = rs.getString("modelo");
                Carro c = get(username);
                AbstractMap.SimpleEntry e = new AbstractMap.SimpleEntry(username, c);
                res.add(e);
            }

        } catch (Exception e) {
            // Database error!
            e.printStackTrace();
            throw new NullPointerException(e.getMessage());
        }
        return res;
    }
}
