package Controller;

import RacingManagerLN.IRacingManagerLN;
import View.View;
import java.io.IOException;
import java.util.*;
import RacingManagerLN.Campeonatos.ISSCampeonato;
import RacingManagerLN.Corridas.ISSCorridas;
import RacingManagerLN.Utilizadores.ISSUtilizador;
import RacingManagerLN.Corridas.*;
import RacingManagerLN.Utilizadores.*;
import RacingManagerLN.Campeonatos.*;


public class Controller {

    private Scanner scan;
    private View view;
    private IRacingManagerLN racingManager;

    public Controller(View view,IRacingManagerLN racingManager) {
        scan = new Scanner(System.in);
        this.view = view;
        this.scan = new Scanner(System.in);
        this.racingManager = racingManager;
    }

    public void start() throws IOException {
        boolean flag = true;
        while(flag){
            View.menuInicial();
            String opt = scan.nextLine();
            switch(opt) {
                case "0":
                    flag = false;
                    break;
                case "1":
                    administrador();
                    break;
                case "2":
                    jogador();
                    break;
                case "3":
                    registarJogador();
                    break;
                default:
                    View.print("Opção inválida.");
                    break;
            }
        }
    }

    public void administrador() {
        loginAdmin();
        while(true) {
            View.menuAdmin();
            String opt = scan.nextLine();
            switch (opt) {
                case "0":
                    return;
                case "1":
                    adicionaCampeonato();
                    break;
                case "2":
                    adicionaCircuito();
                    break;
                case "3":
                    adicionaCarro();
                    break;
                case "4":
                    adicionaPiloto();
                    break;
                default:
                    View.print("Opção inválida\n");
                    break;
            }
        }
    }

    public void adicionaCampeonato(){
        View.adicionarCampeonato();
        String nome = "";
        boolean flag = false;
        boolean print = false;
        while(!flag){
            if(print)
                View.print("Nome inválido\n>");
            nome = scan.nextLine();
            flag = racingManager.nomeValidoC(nome);
            print = true;
        }
        View.listaCircuitos(racingManager.getListCircuitos());
        String circuitos = scan.nextLine();
        racingManager.addCampeonato(nome,circuitos);
    }

    public void adicionaCircuito(){
        View.adicionarCircuito();
        String nome = "";
        boolean flag = false;
        boolean print = false;
        while(!flag){
            if(print)
                View.print("Nome inválido\n>");
            nome = scan.nextLine();
            flag = racingManager.nomeValidoCircuito(nome);
            print = true;
        }
        View.print("Distancia em km:\n>");
        int distancia = Integer.parseInt(scan.nextLine());
        View.print("Numero de curvas:\n>");
        int curvas = Integer.parseInt(scan.nextLine());
        View.print("Numero de chicanes:\n>");
        int chicanes = Integer.parseInt(scan.nextLine());
        int retas = curvas + chicanes;
        List<String> caminho = new ArrayList<>();
        List<Integer> gdu = new ArrayList<>();
        for(int i = 0; i< retas*2; i+=2){
            caminho.add("R");
            int rand = (int)Math.round( Math.random());
            if(rand == 0 && curvas>0) {
                caminho.add("C");
                curvas--;
            }else if (rand == 0 && curvas == 0) {
                caminho.add("CH");
                chicanes--;
            }else if (rand == 1 && chicanes>0) {
                caminho.add("CH");
                chicanes--;
            }else if (rand == 1 && chicanes == 0) {
                caminho.add("C");
                curvas--;
            }
        }
        while(true) {
            View.print("Caminho:\nR=Reta\nC=Curva\nCH=Chicane" + caminho + "\nPara cada parte do circuito, escolha o seu grau de dificuldade.\n" +
                    "Sendo 1=fácil, 2=dificil e 3=impossível, separando as dificuldades por um espaço, mantendo a ordem do caminho." +
                    "\nTodos as chicanes devem ter uma dificuldade igual a 3\n");
            String gdus = scan.nextLine();
            String[] split = gdus.split(" ");
            if (split.length == caminho.size()) {
                for(String s : split){
                    gdu.add(Integer.parseInt(s));
                }
                break;
            }else{
                View.print("GDU's inválidos\n");
            }
        }
        View.print("Numero de voltas:\n>");
        int voltas = Integer.parseInt(scan.nextLine());
        View.print("Tempo de desvio em milisegundos:\n>");
        int temposDesvio = Integer.parseInt(scan.nextLine());
        View.print("TemposBox em milisegundos:\n>");
        int temposBox = Integer.parseInt(scan.nextLine());
        racingManager.addCircuito(nome,distancia,voltas,temposDesvio,temposBox,caminho,gdu);
    }

    public void adicionaCarro(){
        boolean flag = true;
        String classe = "";
        while(flag) {
            View.adicionarCarro();
            String opt = scan.nextLine();
            switch (opt) {
                case "0":
                    return;
                case "1":
                    classe = "PC1";
                    flag = false;
                    break;
                case "2":
                    classe = "PC2";
                    flag = false;
                    break;
                case "3":
                    classe = "GT";
                    flag = false;
                    break;
                case "4":
                    classe = "SC";
                    flag = false;
                    break;
                default:
                    View.print("Opção inválida\n");
                    break;
            }
        }
        View.print("Marca do carro:\n>");
        String marca = scan.nextLine();
        View.print("Modelo do carro:\n>");
        String modelo = scan.nextLine();
        boolean flag2 = racingManager.modeloValidoCarro(modelo);
        while(!flag2){
            View.print("Modelo inválido\n>");
            modelo = scan.nextLine();
            flag2 = racingManager.modeloValidoCarro(modelo);
        }
        View.print("Cilindrada do carro:\n>");
        int cilindrada = Integer.parseInt(scan.nextLine());
        View.print("Potência do motor de combustão:\n>");
        int potencia = Integer.parseInt(scan.nextLine());
        boolean hibrido = false;
        if(!classe.equals("SC")){
            View.print("O carro tem motor híbrido? 0-Não | 1-Sim\n>");
            if(scan.nextLine().equals("1"))
                hibrido = true;
        }
        int potenciaH = 0;
        if(hibrido){
            View.print("Potência do motor híbrido:\n>");
            potenciaH = Integer.parseInt(scan.nextLine());
            classe+="H";
        }
        View.print("Perfil aerodinâmico do carro entre 0 e 1:\n>");
        double pac = Double.parseDouble(scan.nextLine());
        View.print("Modo de motor do carro:\n1-Conservador, 2-Normal ou 3-Agressivo\n>");
        int motor = Integer.parseInt(scan.nextLine());
        racingManager.addCarro(classe,marca,modelo,cilindrada,potencia,pac,motor,potenciaH);
    }

    public void adicionaPiloto(){
        View.adicionarPiloto();
        String nome="";
        boolean flag = false;
        boolean print = false;
        while(!flag){
            if(print)
                View.print("Nome inválido\n>");
            nome = scan.nextLine();
            flag = racingManager.nomeValidoP(nome);
            print = true;
        }
        View.print("Indique o nível de perícia para o critério Chuva vs Tempo seco:\n>");
        double cts = Double.parseDouble(scan.nextLine());
        View.print("Indique o nível de perícia para o critério Segurança vs Agressividade:\n>");
        double sva = Double.parseDouble(scan.nextLine());
        racingManager.addPiloto(nome,cts,sva);
    }

    public void jogador(){
        View.menuJogador();
        int n = Integer.parseInt(scan.nextLine());
        Map<Integer,Jogador> map = new HashMap<>();
        Map<Integer,Carro> map2 = new HashMap<>();
        for(int i = 1; i<=n ; i++){
            map.put(i,new Jogador());
        }
        for(int i = 1; i<=n ; i++){
            View.print("Jogador "+i+" pretende dar login ?\n0-Não | 1-Sim\n>");
            String r = scan.nextLine();
            Jogador j;
            if(r.equals("1")){
                j = loginJogador();
                if(j!=null){
                    map.put(i,j);
                }
            }
        }
        View.listaCampeonato(racingManager.getCampeonatos());
        String opt = scan.nextLine();
        if(opt.equals("0")) return;
        Campeonato campeonato = racingManager.getCampeonatos().get(Integer.parseInt(opt)).clone();
        List<Carro> carros = new ArrayList<>();
        List<Carro> temp = new ArrayList<Carro>(racingManager.getCarros());
        for(int j = 1; j<=n ; j++){
            View.listaCarro(temp,j);
            opt = scan.nextLine();
            Carro carro = temp.get(Integer.parseInt(opt)-1).clone();
            temp.remove(Integer.parseInt(opt)-1);
            carros.add(carro);
            map2.put(j,carro);
        }
        List<Piloto> pilotos = new ArrayList<>();
        List<Piloto> temp2 = new ArrayList<Piloto>(racingManager.getPilotos());
        for(int j = 1; j<=n ; j++){
            View.listaPiloto(temp2,j);
            opt = scan.nextLine();
            Piloto piloto = temp2.get(Integer.parseInt(opt)-1).clone();
            temp2.remove(Integer.parseInt(opt)-1);
            pilotos.add(piloto);
        }
        for(int j = 0; j < carros.size() ; j++){ //associar os pilotos aos carros
            carros.get(j).setPiloto(pilotos.get(j));
            carros.get(j).setJogador(map.get(j+1));
        }
        List<Corrida> newCorridas = new ArrayList<>();
        for(int i = 0; i<campeonato.getCorridas().size();i++){
            Corrida c = campeonato.getCorridas().get(i).clone();
            c.setListaCarros(carros);
            newCorridas.add(c);
        }
        campeonato.setCorridas(newCorridas);

        simular(campeonato,map,map2);

    }

    public Jogador loginJogador(){
        boolean flag = true;
        boolean nomeValido = true;
        Jogador jogador = new Jogador();
        while(flag) {
            if(!nomeValido)
                View.print("Nome ou password inválidos\n");
            View.print("Nome:\n");
            String nome = scan.nextLine();
            View.print("Password:\n>");
            String password = scan.nextLine();
            flag = !racingManager.iniciarSessao("jogador",nome,password);
            if(flag)
                nomeValido = false;
            else
                jogador = new Jogador(nome,password);
        }
        return jogador;
    }

    public Administrador loginAdmin(){
        View.login();
        boolean flag = true;
        boolean nomeValido = true;
        Administrador administrador = new Administrador();
        while(flag) {
            if(!nomeValido)
                View.print("Nome ou password inválidos\n");
            View.print("Nome:\n");
            String nome = scan.nextLine();
            View.print("Password:\n>");
            String password = scan.nextLine();
            flag = !racingManager.iniciarSessao("admin",nome,password);
            if(flag)
                nomeValido = false;
        }
        return administrador;
    }

    public void simular(Campeonato campeonato,Map<Integer,Jogador> loggedIn,Map<Integer,Carro> loggedCarros){
        for(int i = 0; i < campeonato.getCorridas().size() ; i++){
            View.print("Condições da corrida "+i+":\nCircuito: "+campeonato.getCorridas().get(i).getCircuito().getNome()+
                    "\nClima: ");
            if(campeonato.getCorridas().get(i).getClima()==1)
                View.print("Chuva\n");
            else
                View.print("Sol\n");
            for(int j = 0; j<loggedIn.size();j++){
                View.print("Jogador "+j+" pretende alterar afinação do carro?\n0-Não | 1-Sim\n>");
                if(scan.nextLine().equals("1")){
                    alteraAfinacao(campeonato,i,j);
                }
                View.print("Jogador "+j+" pretende alterar os pneus do carro?\n0-Não | 1-Sim\n>");
                if(scan.nextLine().equals("1")){
                    View.print("Escolha um dos seguintes pneus:\n1-Macio, 2-Duro ou 3-Chuva\n>");
                    int pneu = Integer.parseInt(scan.nextLine());
                    campeonato.setPneuCampeonato(i,j,pneu);
                }
            }
            //Afinação e pneus alterados -> começa a simulação
            String res = campeonato.simularProximaCorrida();
            View.print(res+"\n");
            scan.nextLine();

            campeonato.atualizarClassificacao();
            campeonato.atualizarClassificacaoHibrido();
        }
        View.print(campeonato.printClassificacao()+"\n");
        scan.nextLine();
        for(int i = 1; i<loggedIn.size(); i++){
            if(loggedIn.get(i).getNome().equals("")){
                View.print("Jogador "+i+" deseja dar login para guardar os pontos?\n0-Não | 1-Sim\n>");
                String opt = scan.nextLine();
                if(opt.equals("1")){
                    Jogador j = loginJogador();
                    if(j!=null){
                        loggedIn.replace(i,j);
                    }
                }
            }
        }
        Map<String,Integer> classificacao = campeonato.getClassificacao();
        Map<String,Integer> classificacaoH = campeonato.getClassificacaoH();

        for (Map.Entry<String,Integer> entry : classificacao.entrySet()) {
            String[] split = entry.getKey().split(" ");
            Jogador jogador;
            for(int i = 1; i <= loggedCarros.size() ; i++){
                if(loggedCarros.get(i).getMarca().equals(split[0]) && loggedCarros.get(i).getModelo().equals(split[1])){
                    jogador = loggedCarros.get(i).getJogador();
                    for(Jogador j : racingManager.getListJogador()){
                        if(j.getNome().equals(jogador.getNome())){
                            j.addPontos(entry.getValue());
                            Jogador jTemp = new Jogador(jogador.getNome(),jogador.getPassword(),jogador.isVersao(),jogador.getPontos()+ entry.getValue());
                            racingManager.addJogador(jogador.getNome(),jTemp);
                        }
                    }
                }
            }
        }

        for (Map.Entry<String,Integer> entry : classificacaoH.entrySet()) {
            String[] split = entry.getKey().split(" ");
            Jogador jogador;
            for(int i = 1; i <= loggedCarros.size() ; i++){
                if(loggedCarros.get(i).getMarca().equals(split[0]) && loggedCarros.get(i).getModelo().equals(split[1])){
                    jogador = loggedCarros.get(i).getJogador();
                    for(Jogador j : racingManager.getListJogador()){
                        if(j.getNome().equals(jogador.getNome())){
                            j.addPontos(entry.getValue());
                            Jogador jTemp = new Jogador(jogador.getNome(),jogador.getPassword(),jogador.isVersao(),jogador.getPontos()+ entry.getValue());
                            racingManager.addJogador(jogador.getNome(),jTemp);
                        }
                    }
                }
            }
        }
        racingManager.allLogOut();
    }

    public void alteraAfinacao(Campeonato c,int corrida,int j){
        if(c.getCorridas().get(corrida).getCarros().get(j).getClass().getName().equals("SC")){
            View.print("Não é possivel alterar afinação em carros da classe SC\n");
        }else if(c.getCorridas().get(corrida).getCarros().get(j).getNrAfinacoes()>(2*c.getCorridas().size())/3){
            View.print("Limite de afinações excedido\n");
        }else{
            c.getCorridas().get(corrida).getCarros().get(j).incrementAfinacao();
            View.print("Indique um novo valor para o PAC, entre 0 e 1\nCaso não pretenta alterar o PAC prima 2\n>");
            String pac = scan.nextLine();
            if(!pac.equals("2"))
                c.setPacCampeonato(corrida,j,Double.parseDouble(pac));
            View.print("Indique um novo modo de motor\n1-Conservador, 2-Normal, 3-Agressivo ou 0-Não alterar\n>");
            String modo = scan.nextLine();
            if(!modo.equals("0")){
                c.setModoCampeonato(corrida,j,Integer.parseInt(modo));
            }
        }
    }

    public void registarJogador(){
        boolean flag = true;
        View.registarJogador();
        String nome = "";
        String password = "";

        while(flag){
            View.print("Indique o nome:\n>");
            nome = scan.nextLine();
            View.print("Indique a password\n>");
            password = scan.nextLine();
            flag = !racingManager.registaJogador(nome,password);
        }
    }
}
