package RacingManagerLN.Utilizadores;

import java.util.ArrayList;
import java.util.List;

import Data.JogadorDAO;
import Data.AdministradorDAO;
public class SSUtilizador implements  ISSUtilizador{

    private JogadorDAO jogadorDAO;
    private AdministradorDAO administradorDAO;

    public SSUtilizador() {
        this.jogadorDAO = JogadorDAO.getInstance();
        this.administradorDAO = AdministradorDAO.getInstance();
    }

    public boolean iniciarSessao(String tipo, String username, String password){
        if(tipo.equals("admin")){
            Utilizador f = jogadorDAO.get(username);
            if(f!=null) {
                if (f.validaPassword(password)) {
                    if (!f.isLogged()) {
                        this.administradorDAO.logIn(username);
                        return true;
                    }
                }
            }
        }else{
            Utilizador f = jogadorDAO.get(username);
            if(f!=null) {
                if (f.validaPassword(password)) {
                    if (!f.isLogged()) {
                        this.jogadorDAO.logIn(username);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public void terminaSessao(String tipo,String username) {
        if(tipo.equals("admin")){
            Utilizador f = jogadorDAO.get(username);
            this.administradorDAO.logOut(username);
        }else{
            Utilizador f = jogadorDAO.get(username);
            this.jogadorDAO.logOut(username);
        }
    }

    public boolean registaJogador(String nome, String password) {
        Jogador jogador = new Jogador(nome, password);
        if (!jogadorDAO.containsKey(nome)){
            this.jogadorDAO.put(nome, jogador);
            return true;
        }
        return false;
    }

    public List<Administrador> getListAdmins(){
        return new ArrayList<>(administradorDAO.values());
    }

    public List<Jogador> getListJogador(){
        return new ArrayList<>(jogadorDAO.values());
    }

    public boolean isLogged(String nome){
        Jogador j = jogadorDAO.get(nome);
        return j.isLogged();
    }

    public void addJogador(String nome,Jogador j){
        jogadorDAO.put(nome,j);
    }

    public void allLogOut(){
        for(Jogador j : jogadorDAO.values()){
            jogadorDAO.logOut(j.getNome());
        }
    }
}

