package RacingManagerLN.Utilizadores;
import java.util.List;

public interface ISSUtilizador {

    boolean iniciarSessao(String tipo, String username, String password);

    void terminaSessao(String tipo, String username);

    boolean registaJogador(String nome, String password);

    List<Administrador> getListAdmins();

    List<Jogador> getListJogador();

    void addJogador(String nome,Jogador j);

    void allLogOut();
}
