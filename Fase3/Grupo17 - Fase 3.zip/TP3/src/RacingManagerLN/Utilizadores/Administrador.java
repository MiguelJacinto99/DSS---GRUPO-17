package RacingManagerLN.Utilizadores;

public class Administrador extends Utilizador {

    public Administrador() {
        super();
    }

    public Administrador(String n, String pw) {
        super(n,pw);
    }

    public Administrador(Administrador a)
    {
        super(a.getNome(),a.getPassword());
    }

    public Administrador clone()
    {
        return new Administrador(this);
    }


    public String printInfo()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("\nNome: ");sb.append(super.getNome());
        sb.append("\tPassword: ");sb.append(super.getPassword());

        return sb.toString();
    }

}
