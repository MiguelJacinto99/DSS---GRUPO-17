package RacingManagerLN.Utilizadores;

import java.io.Serializable;

public abstract class Utilizador implements Serializable {
    private String nome;
    private String password;
    private boolean logged;

    public Utilizador() {
        this.nome = "";
        this.password = "";
        this.logged = false;
    }

    public Utilizador(String nome, String password) {
        this.nome = nome;
        this.password = password;
    }

    public Utilizador(String nome, String password, boolean logged) {
        this.nome = nome;
        this.password = password;
        this.logged = logged;
    }

    public Utilizador(Utilizador u){
        this.nome = u.getNome();
        this.password = u.getPassword();
        this.logged = isLogged();
    }

    public String getNome() {
        return nome;
    }

    public String getPassword() {
        return password;
    }

    public boolean isLogged() {
        return logged;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setLogged(boolean logged) {
        this.logged = logged;
    }

    public boolean validaPassword(String password){
        return password.equals(this.password);
    }

    public void logIn(){
        this.logged=true;
    }

    public void logOut(){
        this.logged=false;
    }

    public abstract String printInfo();

}
