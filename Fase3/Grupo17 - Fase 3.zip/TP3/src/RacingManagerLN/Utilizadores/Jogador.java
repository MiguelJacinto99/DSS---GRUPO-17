package RacingManagerLN.Utilizadores;

public class Jogador extends Utilizador {

    private boolean versao; //true se premium
    private long pontos;

    public Jogador() {
        super();
    }

    public Jogador(String n, String pw) {
        super(n,pw);
        this.versao = false;
        this.pontos = 0;
    }

    public Jogador(String n, String pw, boolean v) {
        super(n,pw);
        this.versao = v;
        this.pontos = 0;
    }

    public Jogador(String n, String pw, boolean v, long p) {
        super(n,pw);
        this.versao = v;
        this.pontos = p;
    }

    public Jogador(String n, String pw, boolean v, long p, boolean logged) {
        super(n,pw,logged);
        this.versao = v;
        this.pontos = p;
    }

    public Jogador(Jogador a)
    {
        super(a.getNome(),a.getPassword());
        this.versao = a.isVersao();
        this.pontos = a.getPontos();
    }

    public Jogador clone()
    {
        return new Jogador(this);
    }

    public boolean isVersao() {
        return versao;
    }

    public long getPontos() {
        return pontos;
    }

    public void setVersao(boolean versao) {
        this.versao = versao;
    }

    public void setPontos(long pontos) {
        this.pontos = pontos;
    }

    public void addPontos(int p){
        this.pontos += p;
    }

    public String printInfo()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("\nNome: ");sb.append(super.getNome());
        sb.append("\tPassword: ");sb.append(super.getPassword());
        sb.append("\tVersao: ");sb.append(this.isVersao());
        sb.append("\tPontos: ");sb.append(this.getPontos());

        return sb.toString();
    }

}