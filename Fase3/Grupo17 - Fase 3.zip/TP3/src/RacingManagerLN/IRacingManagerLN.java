package RacingManagerLN;

import RacingManagerLN.Campeonatos.Campeonato;
import RacingManagerLN.Campeonatos.Carro;
import RacingManagerLN.Campeonatos.Piloto;
import RacingManagerLN.Corridas.Circuito;
import RacingManagerLN.Utilizadores.Jogador;

import java.util.List;

public interface IRacingManagerLN {
    boolean nomeValidoCircuito(String nome);

    void addCircuito(String nome, int dist, int voltas, long td, long tb, List<String> caminho, List<Integer> gdu);

    List<Circuito> getListCircuitos();

    List<Jogador> getListJogador();

    void addJogador(String nome,Jogador j);

    void allLogOut();

    boolean iniciarSessao(String tipo, String username, String password);

    boolean registaJogador(String nome, String password);

    void addCampeonato(String nome, String circuitos);

    void addCarro(String tipo, String marca, String modelo,int cilindrada,int potencia, double pac, int motor, int potenciaH);

    void addPiloto(String nome, double cts, double sva);

    List<Campeonato> getCampeonatos();

    List<Carro> getCarros();

    List<Piloto> getPilotos();

    boolean nomeValidoC(String nome);

    boolean nomeValidoP(String nome);

    boolean modeloValidoCarro(String modelo);
}
