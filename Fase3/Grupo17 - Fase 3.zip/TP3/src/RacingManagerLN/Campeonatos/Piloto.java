package RacingManagerLN.Campeonatos;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;

public class Piloto implements Serializable
{
    //Variaveis de instancia
    private String nome;
    private double cts;
    private double sva;

    //Construtores
    public Piloto()
    {
        this.nome = "";
        this.cts = 0.0;
        this.sva = 0.0;
    }

    public Piloto(String nome, double cts, double sva)
    {
        this.nome = nome;
        this.cts = cts;
        this.sva = sva;
    }

    public Piloto(Piloto p)
    {
        this.nome = p.getNome();
        this.cts = p.getCts();
        this.sva = p.getSva();
    }

    //Gets e Sets
    public String getNome()
    {
        return this.nome;
    }

    public double getCts() {
        return cts;
    }

    public double getSva() {
        return sva;
    }

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    public void setCts(int cts) {
        this.cts = cts;
    }

    public void setSva(int sva) {
        this.sva = sva;
    }

    //Metodos usuais
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("\nNome: "); sb.append(this.nome);
        sb.append("\tCTS: ");sb.append(this.cts);
        sb.append("\tSVA: ");sb.append(this.sva);
        return sb.toString();
    }

    public Piloto clone()
    {
        return new Piloto(this);
    }

    public boolean equals(Object o)
    {
        if(this == o)
            return true;

        if((o == null) || (this.getClass() != o.getClass()))
            return false;

        Piloto p = (Piloto) o;
        return (this.nome.equals(p.getNome()) &&
                this.cts==p.getCts() &&
                this.sva==p.getSva());
    }

    public void addToFile(){
        try {
            FileWriter fw = new FileWriter("files/pilotos.txt", true);
            fw.append(this.nome).append(" ").append(String.valueOf(this.cts)).append(" ").append(String.valueOf(this.sva)).append("\n");
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
