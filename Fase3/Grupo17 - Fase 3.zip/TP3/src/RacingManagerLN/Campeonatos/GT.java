package RacingManagerLN.Campeonatos;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;


public class GT extends Carro {
    private double taxa;

    public GT()
    {
        super();
    }
    
    public GT(String marca, String modelo, int cilindrada, int potencia, double pac, int motor,double taxa) {
        super(marca,modelo,cilindrada,potencia,pac,motor,(int)((100000/cilindrada)*2.55));
        this.taxa = taxa;
    }

    public GT(String marca, String modelo, int cilindrada, int potencia, double pac, int motor, int fiabilidade,double taxa) {
        super(marca,modelo,cilindrada,potencia,pac,motor,fiabilidade);
        this.taxa = taxa;
    }
    
    public GT(GT p)
    {
        super(p);
    }
    
    public GT clone()
    {
        return new GT(this);
    }

    public int getPotenciaH(){
        return 0;
    }

    public double getTaxa(){
        return taxa;
    }

    public boolean DNF(int etapas,int volta,int totalvoltas, int chuva) {
        Random rand=new Random();
        int min = 0;
        int max = 100;
        double x = min + (max - min) * rand.nextDouble();
        double desgaste = (volta+1)*taxa;
        double probabilidadeDnfEtapa = (100-super.getFiabilidade()-desgaste)/(double)etapas;
        return (x < probabilidadeDnfEtapa);
    }
     
    public boolean equals(Object o)
    {
        if(this==o)
        return true;
        
        if(o==null || this.getClass()!=o.getClass())
        return false;
        
        GT c = (GT) o;
        return ( super.equals(c));
    }

    public void addToFile() throws IOException {
        FileWriter fw = new FileWriter("files/carros.txt", true);
        fw.append(this.getClass().getName()).append(" ").append(super.getMarca()).append(" ").append(super.getModelo()).append(" ");
        fw.append(String.valueOf(super.getCilindrada())).append(" ").append(String.valueOf(super.getPotencia())).append(" ");
        fw.append(String.valueOf(super.getPac())).append(" ").append(String.valueOf(super.getMotor())).append(" ").append(String.valueOf(super.getFiabilidade()));
        fw.append(" ").append(String.valueOf(taxa)).append("\n");
        fw.close();
    }
}
