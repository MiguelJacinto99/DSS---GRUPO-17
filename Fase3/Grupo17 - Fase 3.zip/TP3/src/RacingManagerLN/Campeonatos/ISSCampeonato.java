package RacingManagerLN.Campeonatos;

import java.util.List;

public interface ISSCampeonato {

    void addCampeonato(String nome, String circuitos);

    void addCarro(String tipo, String marca, String modelo,int cilindrada,int potencia, double pac, int motor, int potenciaH);

    void addPiloto(String nome, double cts, double sva);

    List<Campeonato> getCampeonatos();

    List<Carro> getCarros();

    List<Piloto> getPilotos();

    boolean nomeValidoC(String nome);

    boolean nomeValidoP(String nome);

    boolean modeloValidoCarro(String modelo);
}
