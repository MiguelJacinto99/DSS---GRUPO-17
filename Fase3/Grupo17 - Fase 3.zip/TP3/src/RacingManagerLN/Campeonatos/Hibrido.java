package RacingManagerLN.Campeonatos;

public interface Hibrido
{
    public int getPotenciaMotorEletrico();
    public void setPotenciaMotorEletrico(int potencia);
}
