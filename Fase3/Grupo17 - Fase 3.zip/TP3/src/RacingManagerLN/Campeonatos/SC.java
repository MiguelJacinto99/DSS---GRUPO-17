package RacingManagerLN.Campeonatos;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class SC extends Carro
{
    public SC()
    {
        super();
    }

    public SC(String marca, String modelo, int cilindrada, int potencia, double pac, int motor)
    {
        super(marca,modelo,cilindrada,potencia,pac,motor,(int) ((Math.random() * (75 - 70)) + 70)+25);
    }

    public SC(String marca, String modelo, int cilindrada, int potencia, double pac, int motor, int fiabilidade)
    {
        super(marca,modelo,cilindrada,potencia,pac,motor,fiabilidade);
    }
    
    public SC(SC p)
    {
        super(p);
    }
    
    public SC clone()
    {
        return new SC(this);
    }

    public boolean DNF(int etapas,int volta,int totalvoltas, int chuva) {
        Random rand=new Random();
        int min = 0;
        int max = 100;
        double x = min + (max - min) * rand.nextDouble();
        double probabilidadeDnfEtapa = (100-super.getFiabilidade())/(double)etapas;
        return (x < probabilidadeDnfEtapa);
    }

    public int getPotenciaH(){
        return 0;
    }

    public double getTaxa(){
        return 0;
    }
     
    public boolean equals(Object o)
    {
        if(this==o)
        return true;
        
        if(o==null || this.getClass()!=o.getClass())
        return false;
        
        SC c = (SC) o;
        return ( super.equals(c));
    }

    public void addToFile() throws IOException {
        FileWriter fw = new FileWriter("files/carros.txt", true);
        fw.append(this.getClass().getName()).append(" ").append(super.getMarca()).append(" ").append(super.getModelo()).append(" ");
        fw.append(String.valueOf(super.getCilindrada())).append(" ").append(String.valueOf(super.getPotencia())).append(" ");
        fw.append(String.valueOf(super.getPac())).append(" ").append(String.valueOf(super.getMotor())).append(" ").append(String.valueOf(super.getFiabilidade())).append("\n");
        fw.close();
    }
}
