package RacingManagerLN.Campeonatos;

import View.View;
import java.util.ArrayList;
import java.util.List;
import Data.*;
import RacingManagerLN.Corridas.*;

public class SSCampeonato implements ISSCampeonato {
    private CampeonatoDAO campeonatoDAO;
    private CarroDAO carroDAO;
    private PilotoDAO pilotoDAO;
    private SSCorridas ssCorridas;


    public SSCampeonato() {
        this.campeonatoDAO = CampeonatoDAO.getInstance();
        this.carroDAO = CarroDAO.getInstance();
        this.pilotoDAO = PilotoDAO.getInstance();
        this.ssCorridas = new SSCorridas();
    }

    public void addCampeonato(String nome, String circuitos){
        List<Corrida> corridas = new ArrayList<>();
        String[] split = circuitos.split(" ");
        for(String s : split){
            for(Circuito c : ssCorridas.getListCircuitos()){
                if(c.getNome().equals(s)){
                    corridas.add(new Corrida(c,(int)Math.round( Math.random() )));
                }
            }
        }
        Campeonato c = new Campeonato(nome,corridas);
        campeonatoDAO.put(nome,c);
    }

    public void addCarro(String tipo, String marca, String modelo,int cilindrada,int potencia, double pac, int motor, int potenciaH){
        boolean hibrido = true;
        if(potenciaH == 0){
            hibrido = false;
        }
        Carro c = new PC1();
        switch (tipo) {
            case "C1":
                if(hibrido){
                    int f = (int) ((Math.random() * (98 - 95)) + 95);
                    if((int)(Math.floor(potenciaH/100D)) == 1)
                        c = new PC1H(marca,modelo,cilindrada,potencia,pac,motor,f-1,potenciaH);
                    else if((int)(Math.floor(potenciaH/100D)) == 2)
                        c = new PC1H(marca,modelo,cilindrada,potencia,pac,motor,f-2,potenciaH);
                    else
                        c = new PC1H(marca,modelo,cilindrada,potencia,pac,motor,f-3,potenciaH);
                }else
                    c = new PC1(marca,modelo,cilindrada,potencia,pac,motor);
                break;
            case "C2":
                if(hibrido){
                    int fiabilidade;
                    if((int)(Math.floor(cilindrada/1000D)) == 1)
                        fiabilidade = 97;
                    else if((int)(Math.floor(cilindrada/1000D)) == 2)
                        fiabilidade = 98;
                    else
                        fiabilidade = 99;
                    if((int)(Math.floor(potenciaH/100D)) == 1)
                        c = new PC2H(marca,modelo,cilindrada,potencia,pac,motor,fiabilidade-1,potenciaH);
                    else if((int)(Math.floor(potenciaH/100D)) == 2)
                        c = new PC2H(marca,modelo,cilindrada,potencia,pac,motor,fiabilidade-2,potenciaH);
                    else
                        c = new PC2H(marca,modelo,cilindrada,potencia,pac,motor,fiabilidade-3,potenciaH);
                }
                else {
                    if((int)(Math.floor(cilindrada/1000D)) == 1)
                        c = new PC2(marca, modelo, cilindrada, potencia, pac, motor,97);
                    else if((int)(Math.floor(cilindrada/1000D)) == 2)
                        c = new PC2(marca, modelo, cilindrada, potencia, pac, motor,98);
                    else
                        c = new PC2(marca, modelo, cilindrada, potencia, pac, motor,99);
                }
                break;
            case "GT":
                if(hibrido) {
                    int fiabilidade;
                    if((int)(Math.floor(cilindrada/1000D)) == 2)
                        fiabilidade = 100;
                    else if((int)(Math.floor(cilindrada/1000D)) == 3)
                        fiabilidade = 99;
                    else
                        fiabilidade = 98;
                    if ((int) (Math.floor(potenciaH / 100D)) == 1){
                        c = new GTH(marca, modelo, cilindrada, potencia, pac, motor, fiabilidade-1, potenciaH,Math.random()/2D);
                    }
                    else if ((int) (Math.floor(potenciaH / 100D)) == 2){
                        c = new GTH(marca, modelo, cilindrada, potencia, pac, motor, fiabilidade-2, potenciaH,Math.random()/2D);
                    }
                    else{
                        c = new GTH(marca, modelo, cilindrada, potencia, pac, motor, fiabilidade-3, potenciaH,Math.random()/2D);
                    }
                }
                else {
                    if((int)(Math.floor(cilindrada/1000D)) == 2)
                        c = new GT(marca, modelo, cilindrada, potencia, pac, motor,100,Math.random()/2D);
                    else if((int)(Math.floor(cilindrada/1000D)) == 3)
                        c = new GT(marca, modelo, cilindrada, potencia, pac, motor,99,Math.random()/2D);
                    else
                        c = new GT(marca, modelo, cilindrada, potencia, pac, motor,98,Math.random()/2D);
                }
                break;
            case "SC":
                c = new SC(marca, modelo, cilindrada, potencia, pac, motor);
                break;
            default:
                View.print("Opção inválida.\n");
        }
        carroDAO.put(modelo,c);
    }

    public void addPiloto(String nome, double cts, double sva){
        Piloto p = new Piloto(nome,cts,sva);
        pilotoDAO.put(nome,p);
    }

    public List<Campeonato> getCampeonatos(){
        return new ArrayList<>(campeonatoDAO.values());
    }

    public List<Carro> getCarros(){
        return new ArrayList<>(carroDAO.values());
    }

    public List<Piloto> getPilotos(){
        return new ArrayList<>(pilotoDAO.values());
    }

    public boolean nomeValidoC(String nome){
        return !campeonatoDAO.containsKey(nome);
    }

    public boolean nomeValidoP(String nome){
        return !pilotoDAO.containsKey(nome);
    }

    public boolean modeloValidoCarro(String modelo){
        return !carroDAO.containsKey(modelo);
    }

}
