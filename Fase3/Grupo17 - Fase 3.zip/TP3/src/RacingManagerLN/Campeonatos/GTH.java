package RacingManagerLN.Campeonatos;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class GTH extends GT implements Hibrido {
    private int motor_eletrico;
    private double taxa;
    
    public GTH()
    {
        super();
        this.motor_eletrico = 0;
        this.taxa = 0;
    }

    public GTH(String marca, String modelo, int cilindrada, int potencia, double pac, int motor, int eletrico, double taxa)
    {
        super(marca,modelo,cilindrada,potencia,pac,motor,95);
        this.motor_eletrico = eletrico;
        this.taxa = taxa;
    }

    public GTH(String marca, String modelo, int cilindrada, int potencia, double pac, int motor, int f, int eletrico,double taxa)
    {
        super(marca,modelo,cilindrada,potencia,pac,motor,f);
        this.motor_eletrico = eletrico;
        this.taxa = taxa;
    }
    
    public GTH(GTH p)
    {
        super(p);
        this.motor_eletrico = p.getPotenciaMotorEletrico();
        this.taxa = p.getTaxa();
    }

    public int getPotenciaH(){
        return motor_eletrico;
    }

    public double getTaxa(){
        return taxa;
    }
    
    public GTH clone()
    {
        return new GTH(this);
    }
    
    public int getPotenciaMotorEletrico()
    {
        return this.motor_eletrico;
    }
    
    public void setPotenciaMotorEletrico(int potencia)
    {
        this.motor_eletrico = potencia;
    }

    public boolean DNF(int etapas,int volta,int totalvoltas, int chuva) {
        Random rand=new Random();
        int min = 0;
        int max = 100;
        double x = min + (max - min) * rand.nextDouble();
        double desgaste = (volta+1)*taxa;
        double probabilidadeDnfEtapa = (100-super.getFiabilidade()-desgaste)/(double)etapas;
        return (x < probabilidadeDnfEtapa);
    }
    
    public boolean equals(Object o)
    {
        if(this==o)
        return true;
        
        if(o==null || this.getClass()!=o.getClass())
        return false;
        
        GTH c = (GTH) o;
        return ( super.equals(c) && this.motor_eletrico == c.getPotenciaMotorEletrico());
    }

    public void addToFile() throws IOException {
        FileWriter fw = new FileWriter("files/carros.txt", true);
        fw.append(this.getClass().getName()).append(" ").append(super.getMarca()).append(" ").append(super.getModelo()).append(" ");
        fw.append(String.valueOf(super.getCilindrada())).append(" ").append(String.valueOf(super.getPotencia())).append(" ");
        fw.append(String.valueOf(super.getPac())).append(" ").append(String.valueOf(super.getMotor())).append(" ").append(String.valueOf(super.getFiabilidade()));
        fw.append(" ").append(String.valueOf(this.motor_eletrico));
        fw.append(" ").append(String.valueOf(taxa)).append("\n");
        fw.close();
    }
}
