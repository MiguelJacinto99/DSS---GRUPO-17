package RacingManagerLN.Campeonatos;

import java.io.IOException;
import java.io.Serializable;
import RacingManagerLN.Utilizadores.Jogador;
import RacingManagerLN.Corridas.Circuito;

public abstract class Carro implements Comparable<Carro>,Serializable
{
    //Variaveis de instancia
    private String marca;
    private String modelo;
    private int cilindrada;
    private int potencia;
    private int fiabilidade;
    //afinação mecanica, apenas C1 e C2 podem alterar estes valores (pac,motor)
    private double pac;
    private int motor; //1-conservador, 2-normal ou 3-agressivo
    //
    private long tempo;
    private boolean dnf;
    private int pneu; //1-macio, 2-duro ou 3-chuva

    private Piloto piloto;
    private Jogador jogador;

    private int nrAfinacoes;
    /* Construtores */
    public Carro()
    {
        this.marca = "";
        this.modelo = "";
        this.cilindrada = 0;
        this.potencia = 0;
        this.fiabilidade = 0;
        this.pac = 0.0;
        this.tempo = 0;
        this.dnf = false;
        this.pneu = 2;
        this.motor = 2;
        this.piloto = new Piloto();
        this.jogador = new Jogador();
        this.nrAfinacoes = 0;
    }
    
    public Carro(String marca, String modelo, int cilindrada, int potencia, double pac, int motor, int fiabilidade)
    {
        this.marca = marca;
        this.modelo = modelo;
        this.cilindrada = cilindrada;
        this.potencia = potencia;
        this.fiabilidade = fiabilidade;
        this.pac = pac;
        this.tempo = 0;
        this.dnf = false;
        this.pneu = 2;
        this.motor = motor;
        this.piloto = new Piloto();
        this.jogador = new Jogador();
        this.nrAfinacoes = 0;
    }

    public Carro(Carro c)
    {
       this.marca = c.getMarca();
       this.modelo = c.getModelo();
       this.cilindrada = c.getCilindrada();
       this.potencia = c.getPotencia();
       this.piloto = c.getPiloto();
       this.fiabilidade = c.getFiabilidade();
       this.pac = c.getPac();
       this.tempo = c.getTempo();
       this.dnf = c.getDNF();
       this.pneu = c.getPneu();
       this.motor = c.getMotor();
       this.nrAfinacoes = c.getNrAfinacoes();
    }
    
    /* Gets e sets */
    public long getTempo()
    {
        return this.tempo;
    }

    public int getNrAfinacoes() {
        return nrAfinacoes;
    }

    public String getMarca()
    {
        return this.marca;
    }
    
    public String getModelo()
    {
        return this.modelo;
    }
    
    public int getCilindrada()
    {
        return this.cilindrada;
    }
    
    public int getPotencia()
    {
        return this.potencia;
    }

    public Piloto getPiloto()
    {
        return this.piloto.clone();
    }
    
    public int getFiabilidade()
    {
        return this.fiabilidade;
    }

    public double getPac() {
        return pac;
    }

    public boolean getDNF()
    {
        return this.dnf;
    }

    public boolean isDnf() {
        return dnf;
    }

    public int getPneu() {
        return pneu;
    }

    public int getMotor() {
        return motor;
    }

    public Jogador getJogador() {
        return jogador;
    }

    public void setMarca(String marca)
    {
        this.marca = marca;
    }
    
    public void setModelo(String modelo)
    {
        this.modelo = modelo;
    }
    
    public void setCilindrada(int cilindrada)
    {
        this.cilindrada = cilindrada;
    }
    
    public void setPotencia(int potencia)
    {
        this.potencia = potencia;
    }

    public void setEquipa(Piloto p)
    {
        this.piloto = p.clone();
    }
    
    public void setTempo(long t)
    {
        this.tempo = t;
    }
    
    public void setDNF(boolean b)
    {
        this.dnf = b;
    }

    public void setPac(double pac) {
        this.pac = pac;
    }

    public void setPneu(int pneu) {
        this.pneu = pneu;
    }

    public void setMotor(int motor) {
        this.motor = motor;
    }

    public void incrementAfinacao(){
        this.nrAfinacoes++;
    }

    public void setPiloto(Piloto piloto) {
        this.piloto = piloto;
    }

    public void setJogador(Jogador jogador) {
        this.jogador = jogador;
    }

    /* Metodos usuais */
    public abstract Carro clone();
    
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("\nMarca: ");sb.append(this.marca);
        sb.append("\nModelo: ");sb.append(this.modelo);
        sb.append("\nCilindrada: ");sb.append(this.cilindrada);
        sb.append("\nPotencia: ");sb.append(this.potencia);
        sb.append("\nFiabiliade: ");sb.append(this.fiabilidade);
        sb.append("\nPAC: ");sb.append(this.pac);
        //sb.append("\nJogador:  ");sb.append(this.jogador);
        //sb.append("\nPiloto:   ");sb.append(this.piloto);
        return sb.toString();
    }
    
    public boolean equals(Object o) {
        if (this == o)
            return true;

        if (o == null || this.getClass() != o.getClass())
            return false;

        Carro c = (Carro) o;
        return (this.marca.equals(c.getMarca()) &&
                this.modelo.equals(c.getModelo()) &&
                this.cilindrada == c.getCilindrada() &&
                this.potencia == c.getPotencia() &&
                this.piloto.equals(c.getPiloto()) &&
                this.fiabilidade == c.getFiabilidade() &&
                this.pac == c.getPac() &&
                this.tempo == c.getTempo() &&
                this.dnf == c.getDNF());
    }

    public int compareTo(Carro c)
    {
        if(this.tempo < c.getTempo())
            return -1;
        if(this.tempo > c.getTempo())
            return 1;
        if(this.tempo == c.getTempo() && this.modelo.equals(c.getModelo()))
            return 0;
        else
            return 1;
    }


    public long tempoProximaEtapa(String tipo, int gdu,double dist,Circuito c, int clima, int volta)
    {
        Piloto p1 = this.getPiloto();
        long minimum = 0;
        long maximum2 = 5000;
        long maximum = 1000;
        long fator_sorte = minimum + Double.valueOf(Math.random()*(maximum-minimum)).intValue();
        long fator_sorte2 = minimum + Double.valueOf(Math.random()*(maximum2-minimum)).intValue();
        long tempo = 0;
        if(tipo.equals("R")){ //reta
            tempo = (long) ((dist*3600000)/(Math.cbrt(potencia)*31-20L*clima*p1.getCts()+10L*p1.getSva()+10L/gdu)) + fator_sorte;
            //tempo = factor_sorte2;
        }else if(tipo.equals("C")){ //curva
            tempo = (long) ((dist*3600000)/((Math.cbrt(potencia)*31)/2-20L*clima*p1.getCts()+10L*p1.getSva()+10L/gdu)) + fator_sorte;
            //tempo = factor_sorte2;
        }else{ // chicane
            tempo = (long) ((dist*3600000)/((Math.cbrt(potencia)*31)/3-20L*clima*p1.getCts()+10L*p1.getSva()+10L/gdu)) + fator_sorte;
            //tempo = factor_sorte2;
        }
        if(pneu == 1){ //macio
            tempo+= 10L;
        }
        if(pneu == 2){ //duro
            tempo+= 5L;
        }
        if(pneu == 3){ //chuva
            tempo+= clima*5L;
        }
        return tempo;
    }

    /**
     * define se o carro desiste (true desiste, false continua em prova)
     */
    public abstract boolean DNF(int etapas,int volta,int totalvoltas,int clima);

    public abstract int getPotenciaH();

    public abstract double getTaxa();

    public abstract void addToFile() throws IOException;
}
