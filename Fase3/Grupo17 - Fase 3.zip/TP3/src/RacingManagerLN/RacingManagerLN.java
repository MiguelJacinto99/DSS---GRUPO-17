package RacingManagerLN;

import RacingManagerLN.Campeonatos.*;
import RacingManagerLN.Corridas.Circuito;
import RacingManagerLN.Corridas.ISSCorridas;
import RacingManagerLN.Corridas.SSCorridas;
import RacingManagerLN.Utilizadores.ISSUtilizador;
import RacingManagerLN.Utilizadores.Jogador;
import RacingManagerLN.Utilizadores.SSUtilizador;

import java.util.List;

public class RacingManagerLN implements IRacingManagerLN{
    private ISSCampeonato campeonato;
    private ISSUtilizador utilizador;
    private ISSCorridas corrida;

    public RacingManagerLN() {
        this.campeonato = new SSCampeonato();
        this.utilizador = new SSUtilizador();
        this.corrida = new SSCorridas();
    }

    public boolean nomeValidoCircuito(String nome){
        return corrida.nomeValidoCircuito(nome);
    }

    public void addCircuito(String nome, int dist, int voltas, long td, long tb, List<String> caminho, List<Integer> gdu){
        corrida.addCircuito(nome,dist,voltas,td,tb,caminho,gdu);
    }

    public List<Circuito> getListCircuitos(){
        return corrida.getListCircuitos();
    }

    public List<Jogador> getListJogador(){
        return utilizador.getListJogador();
    }

    public void addJogador(String nome,Jogador j){
        utilizador.addJogador(nome,j);
    }

    public void allLogOut(){
        utilizador.allLogOut();
    }

    public boolean iniciarSessao(String tipo, String username, String password){
        return utilizador.iniciarSessao(tipo,username,password);
    }

    public boolean registaJogador(String nome, String password){
        return utilizador.registaJogador(nome,password);
    }

    public void addCampeonato(String nome, String circuitos){
        campeonato.addCampeonato(nome,circuitos);
    }

    public void addCarro(String tipo, String marca, String modelo,int cilindrada,int potencia, double pac, int motor, int potenciaH){
        campeonato.addCarro(tipo,marca,modelo, cilindrada, potencia,pac,motor,potenciaH);
    }

    public void addPiloto(String nome, double cts, double sva){
        campeonato.addPiloto(nome,cts,sva);
    }

    public List<Campeonato> getCampeonatos(){
        return campeonato.getCampeonatos();
    }

    public List<Carro> getCarros(){
        return campeonato.getCarros();
    }

    public List<Piloto> getPilotos(){
        return campeonato.getPilotos();
    }

    public boolean nomeValidoC(String nome){
        return campeonato.nomeValidoC(nome);
    }

    public boolean nomeValidoP(String nome){
        return campeonato.nomeValidoP(nome);
    }

    public boolean modeloValidoCarro(String modelo){
        return campeonato.modeloValidoCarro(modelo);
    }
}
