package RacingManagerLN.Corridas;

import java.util.List;
import java.util.Set;

import RacingManagerLN.Campeonatos.Carro;

public interface ISSCorridas {

    String simulaCorrida(Corrida corrida);

    Set<Carro> getResultado(Corrida corrida);

    Circuito getCircuito(Corrida corrida);

    boolean nomeValidoCircuito(String nome);

    void addCircuito(String nome, int dist, int voltas, long td, long tb, List<String> caminho, List<Integer> gdu);

    List<Circuito> getListCircuitos();

    String apresentaCondicoes(Corrida corrida);
}
