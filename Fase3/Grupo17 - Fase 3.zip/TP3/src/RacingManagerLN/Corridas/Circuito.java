package RacingManagerLN.Corridas;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

public class Circuito implements Serializable
{
    /* Variaveis instancia */
    private String nome;
    private int distancia;
    private int voltas;
    //private long tempoMedio;
    //private Map<String,Long> temposMedios;
    private long tempoDesvio;
    private long tempoBox;
    private Record record;

    private List<String> caminho;
    private List<Integer> dificuldade;
    /* Construtores */
    public Circuito()
    {
        this.nome = "";
        this.distancia = 0;
        this.voltas = 0;
        this.tempoDesvio = 0;
        this.tempoBox = 0;
        this.record = new Record();
        this.caminho = new ArrayList<>();
        this.dificuldade = new ArrayList<>();
    }

    public Circuito(String n,int d, int v, long ds, long b, String cam, String dif)
    {
        this.nome = n;
        this.distancia = d;
        this.voltas = v;
        this.tempoDesvio = ds;
        this.tempoBox = b;
        List<String> caminho = new ArrayList<>();
        List<Integer> dificuldade = new ArrayList<>();
        String[] split = cam.split(" ");
        for(String s : split){
            caminho.add(s);
        }
        split = dif.split(" ");
        for(String s : split){
            dificuldade.add(Integer.parseInt(s));
        }
        this.caminho = caminho;
        this.dificuldade = dificuldade;
        this.record = new Record();
    }

    public Circuito(String n,int d, int v, long ds, long b, List<String> caminho, List<Integer> dificuldade)
    {
        this.nome = n;
        this.distancia = d;
        this.voltas = v;
        this.tempoDesvio = ds;
        this.tempoBox = b;
        this.caminho = caminho;
        this.dificuldade = dificuldade;
        this.record = new Record();
    }
    
    public Circuito(String n,int d, int v, long ds, long b, Record r, List<String> caminho, List<Integer> dificuldade)
    {
        this.nome = n;
        this.distancia = d;
        this.voltas = v;
        this.tempoDesvio = ds;
        this.tempoBox = b;
        this.record = r.clone();
        this.caminho = caminho;
        this.dificuldade = dificuldade;
    }
    
    public Circuito(Circuito c)
    {
        this.nome = c.getNome();
        this.distancia = c.getDistancia();
        this.voltas = c.getVoltas();
        this.tempoDesvio = c.getTempoDesvio();
        this.tempoBox = c.getTempoBox();
        this.record = c.getRecord();
        this.caminho = c.getCaminho();
        this.dificuldade = c.getDificuldade();
    }
    
    /* Gets e Sets */
    public String getNome()
    {
        return this.nome;
    }
    
    public int getDistancia()
    {
        return this.distancia;
    }
    
    public int getVoltas()
    {
        return this.voltas;
    }
    
    public long getTempoDesvio()
    {
        return this.tempoDesvio;
    }
    
    public long getTempoBox()
    {
        return this.tempoBox;
    }
    
    public Record getRecord()
    {
        return this.record.clone();
    }

    public List<String> getCaminho() {
        return caminho;
    }

    public List<Integer> getDificuldade() {
        return dificuldade;
    }

    public void setNome(String n)
    {
        this.nome = n;
    }
    
    public void setDistancia(int d)
    {
        this.distancia = d;
    }
    
    public void setVoltas(int v)
    {
        this.voltas = v;
    }
    
    public void setTempoDesvio(long ds)
    {
        this.tempoDesvio = ds;
    }
    
    public void setTempoBox(long b)
    {
        this.tempoBox = b;
    }
    
    public void setRecord(Record r)
    {
        this.record = r.clone();
    }
    
    /* Metodos usuais */
    public Circuito clone()
    {
        return new Circuito(this);
    }

    public String caminhoToString(){
        StringBuilder sb = new StringBuilder();
        for(String s : caminho){
            sb.append(s);
            sb.append(" ");
        }
        sb.deleteCharAt(sb.length()-1);
        return sb.toString();
    }

    public String dificuldadeToString(){
        StringBuilder sb = new StringBuilder();
        for(int i : dificuldade){
            sb.append(i);
            sb.append(" ");
        }
        sb.deleteCharAt(sb.length()-1);
        return sb.toString();
    }
    
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nNome: ");sb.append(this.nome);
        sb.append("\nDistancia: ");sb.append(this.distancia);
        sb.append("\nNumero de voltas: ");sb.append(this.voltas);
        sb.append("\nDesvio Tempo: ");sb.append(TimeConverter.toTimeFormat(this.tempoDesvio));
        sb.append("\nTempo Box: ");sb.append(TimeConverter.toTimeFormat(this.tempoBox));
        sb.append("\nCaminho: ");sb.append(this.caminho);
        sb.append("\nDificuldade: ");sb.append(this.dificuldade);
        return sb.toString();
    }
    
    public boolean equals(Object o)
    {
       if(this == o)
       return true;
       
       if(o == null || this.getClass() != o.getClass())
       return false;
       
       Circuito c = (Circuito) o;
       return ( this.nome.equals(c.getNome()) &&
                this.distancia == c.getDistancia() &&
                this.voltas == c.getVoltas() &&
                //this.tempoMedio == c.getTempoMedio() &&
                this.tempoDesvio == c.getTempoDesvio() &&
                this.tempoBox == c.getTempoBox() &&
                this.record.equals(c.getRecord()) &&
               this.caminho.equals(c.getCaminho()) &&
               this.dificuldade.equals(c.getDificuldade()));
    }

    public void addToFile(){
        try {
            FileWriter fw = new FileWriter("files/circuitos.txt", true);
            fw.append(this.nome).append(" ").append(String.valueOf(this.distancia)).append(" ").append(String.valueOf(this.voltas)).append("\n");
            fw.append(String.valueOf(this.tempoDesvio)).append(" ").append(String.valueOf(this.tempoBox)).append("\n");
            for(String s : caminho)
                fw.append(s).append(" ");
            fw.append("\n");
            for(int i : dificuldade)
                fw.append(String.valueOf(i)).append(" ");
            fw.append("\n");
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    
}
