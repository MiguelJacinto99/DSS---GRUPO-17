package RacingManagerLN.Corridas;

import java.util.*;
import Data.CircuitoDAO;
import RacingManagerLN.Campeonatos.Carro;

public class SSCorridas implements  ISSCorridas{
    private CircuitoDAO circuitoDAO;

    public SSCorridas(){
        this.circuitoDAO = CircuitoDAO.getInstance();
    }

    public String simulaCorrida(Corrida corrida){
        corrida.simulaCorrida();
        String res = corrida.printResultados();
        return res;
    }

    public String simulaProximaVolta(Corrida corrida){
        corrida.simulaCorrida();
        String res = corrida.printResultados();
        return res;
    }

    public Set<Carro> getResultado(Corrida corrida){
        return corrida.getResultados();
    }

    public Circuito getCircuito(Corrida corrida){
        return corrida.getCircuito();
    }

    public boolean nomeValidoCircuito(String nome){
        return !circuitoDAO.containsKey(nome);
    }

    public void addCircuito(String nome, int dist, int voltas, long td, long tb, List<String> caminho,List<Integer> gdu){
        Circuito c = new Circuito(nome,dist,voltas,td,tb,new Record(),caminho,gdu);
        circuitoDAO.put(nome,c);
    }

    public List<Circuito> getListCircuitos(){
        return new ArrayList<>(circuitoDAO.values());
    }

    public String apresentaCondicoes(Corrida corrida){
        return corrida.condicoesToString();
    }
}
