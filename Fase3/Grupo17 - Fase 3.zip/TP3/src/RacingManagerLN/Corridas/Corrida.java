package RacingManagerLN.Corridas;

import java.util.*;
import java.io.Serializable;
import RacingManagerLN.Campeonatos.Carro;
import RacingManagerLN.Campeonatos.Hibrido;


public class Corrida implements Serializable
{
    //variaveis de instancia
    private List<Carro> listaCarros;
    private Circuito circuito;
    private Set<Carro> resultados;
    private List<Carro> primeiroVolta;
    private Map<Carro, Integer> dnf;
    private int clima; //1-chove 0-sol
    private String etapas;

    //Construtores
    public Corrida()
    {
        this.listaCarros = new ArrayList<Carro>();
        this.circuito = new Circuito();
        this.resultados = new TreeSet<Carro>();
        //this.bestLap = new HashMap<Carro,Long>();
        this.primeiroVolta = new ArrayList<Carro>();
        this.dnf = new HashMap<Carro,Integer>();
        Random rand=new Random();
        int x=rand.nextInt(2);
        this.clima = x;
        this.etapas = "";
    }

    public Corrida(Circuito circuito, int clima)
    {
        this.listaCarros = new ArrayList<Carro>();
        this.circuito = circuito;
        this.resultados = new TreeSet<Carro>();
        //this.bestLap = new HashMap<Carro,Long>();
        this.primeiroVolta = new ArrayList<Carro>();
        this.dnf = new HashMap<Carro,Integer>();
        Random rand=new Random();
        this.clima = clima;
        this.etapas = "";
    }

    public Corrida(List<Carro> l, Circuito c, Set<Carro> r, List<Carro> p, int clima)
    {
        this();
        for(Carro car: l)
        {
            this.listaCarros.add(car);
        }
        this.circuito = c.clone();
        for(Carro car: r)
        {
            this.resultados.add(car.clone());
        }
        for(Carro x : p)
        {
            this.primeiroVolta.add(x.clone());
        }
        this.clima = clima;
        this.etapas = "";
    }



    public Corrida(Corrida c)
    {
        this.listaCarros = c.getCarros();
        this.circuito = c.getCircuito();
        this.resultados = c.getResultados();
        this.primeiroVolta = c.getPrimeiroVolta();
        this.dnf = c.getDNF();
        this.clima = c.getClima();
        this.etapas = c.getEtapas();
    }

    public String getEtapas() {
        return etapas;
    }

    //Gets e sets
    public List<Carro> getCarros() {
        ArrayList<Carro> aux = new ArrayList<Carro>();
        for(Carro c: this.listaCarros)
        {
            aux.add(c.clone());
        }
        return aux;
    }

    public Circuito getCircuito()
    {
        return this.circuito.clone();
    }


    public Set<Carro> getResultados()
    {
        TreeSet<Carro> aux = new TreeSet<Carro>();
        for(Carro c : this.resultados)
        {
            aux.add(c.clone());
        }
        return aux;
    }

    public Map<Carro,Integer> getDNF()
    {
        HashMap<Carro,Integer> aux = new HashMap<Carro,Integer>();
        for(Carro c : this.dnf.keySet())
        {
            aux.put(c.clone(), this.dnf.get(c));
        }
        return aux;
    }

    public int getClima()
    {
        return this.clima;
    }


    public List<Carro> getPrimeiroVolta()
    {
        ArrayList<Carro> aux = new ArrayList<Carro>();
        for(Carro c : this.primeiroVolta)
        {
            aux.add(c.clone());
        }
        return aux;
    }

    public void setPacCorrida(int carro,double pac){
        listaCarros.get(carro).setPac(pac);
    }

    public void setModoCorrida(int carro,int modo){
        listaCarros.get(carro).setMotor(modo);
    }

    public void setPneuCorrida(int carro,int pneu){
        listaCarros.get(carro).setPneu(pneu);
    }

    public void setCircuito(Circuito c)
    {
        this.circuito = c.clone();
    }

    public void setListaCarros(List<Carro> listaCarros) {
        for(Carro c : listaCarros)
        {
            this.listaCarros.add(c.clone());
        }
    }

    public Corrida clone()
    {
        return new Corrida(this);
    }

    public void adicionarCarro(Carro c)
    {
        this.listaCarros.add(c.clone());
    }

    public void adicionarCarro(List<Carro> l)
    {
        for(Carro c : l)
        {
            this.listaCarros.add(c.clone());
        }
    }

    public int totalCarros()
    {
        return this.listaCarros.size();
    }

    public void removerCarro(Carro c)
    {
        this.listaCarros.remove(c);
    }

    public void limpaListaCarros()
    {
        this.listaCarros.clear();
    }

    public void simulaCorrida()
    {
        int voltas = this.circuito.getVoltas();
        long t_aux, t_volta;
        ArrayList<Carro> aux = new ArrayList<Carro>();
        HashMap<Carro,Integer> temp = new HashMap<Carro,Integer>();
        Set<Carro> resAntes = new TreeSet<>();
        Set<Carro> resDepois = new TreeSet<>();
        boolean flagEtapas = false;
        for(Carro c : this.listaCarros)
        {
            aux.add(c.clone());
        }
        for(int i=0; i<voltas; i++)
        {
            etapas+="---------------Volta "+(i+1)+"---------------\n";
            for(int j = 0;j<circuito.getCaminho().size();j++) {
                for(Carro c : aux) { //simula curvas,retas e chicanes em separado
                    if (!c.getDNF()) //verifica se o carro esta acidentado
                    {
                        if (c.DNF(circuito.getCaminho().size(),i, voltas, this.clima)) //verifica se o carro tem acidente na volta
                        {
                            c.setDNF(true);
                            temp.put(c.clone(), i);
                            if(!flagEtapas){
                                if(circuito.getCaminho().get(j).equals("R")){
                                    etapas += "-----Reta " + (j + 1) + ":\n";
                                }
                                if(circuito.getCaminho().get(j).equals("C")){
                                    etapas += "-----Curva " + (j + 1) + ":\n";
                                }
                                if(circuito.getCaminho().get(j).equals("CH")){
                                    etapas += "-----Chicane " + (j + 1) + ":\n";
                                }
                            }
                            etapas += "DNF: "+c.getMarca()+" "+c.getModelo()+"\n";
                            flagEtapas = true;
                        } else {
                            double distanciaEtapas = circuito.getDistancia()/((double)circuito.getCaminho().size());
                            t_aux = c.getTempo(); //tempo feito ate ao momento
                            if (c instanceof Hibrido h) {
                                int motor = h.getPotenciaMotorEletrico();
                                t_volta = c.tempoProximaEtapa(circuito.getCaminho().get(j),circuito.getDificuldade().get(j),
                                        distanciaEtapas,circuito,clima,i) - motor*10L;
                            } else
                                t_volta = c.tempoProximaEtapa(circuito.getCaminho().get(j),circuito.getDificuldade().get(j),
                                        distanciaEtapas,circuito,clima,i);
                            c.setTempo(t_aux + t_volta);
                            //atualizar record
                            if (this.circuito.getRecord().getTempo() > t_volta) {
                                Record r = new Record(t_volta, c.getPiloto(), c.clone());
                                this.circuito.setRecord(r);
                           }
                        }
                    }
                    if(!c.getDNF()) {
                        resDepois.add(c);
                    }else{
                        resAntes.remove(c);
                    }
                }
                List<Carro> antes = new ArrayList<>(resAntes);
                List<Carro> depois = new ArrayList<>(resDepois);
                if(!resAntes.isEmpty()){
                    int size = antes.size();
                    for(int posi = 1;posi<size;posi++){
                        int newPosi;
                        if(posi<=depois.size()){
                            newPosi = posi;
                        } else{
                            newPosi = depois.size();
                        }
                        for(int p2 = 0; p2<newPosi ;p2++){
                            Carro carroA = antes.get(posi);
                            Carro carroD = depois.get(p2);
                            if(carroA.getMarca().equals(carroD.getMarca()) && carroA.getModelo().equals(carroD.getModelo())){
                                int n = posi-p2;
                                for(int p3 = p2+1; p3<p2+1+n;p3++){
                                    if(p3<depois.size()) {
                                        Carro ult = depois.get(p3);
                                        if (!flagEtapas) {
                                            if (circuito.getCaminho().get(j).equals("R")) {
                                                etapas += "-----Reta " + (j + 1) + ":\n";
                                            }
                                            if (circuito.getCaminho().get(j).equals("C")) {
                                                etapas += "-----Curva " + (j + 1) + ":\n";
                                            }
                                            if (circuito.getCaminho().get(j).equals("CH")) {
                                                etapas += "-----Chicane " + (j + 1) + ":\n";
                                            }
                                        }
                                        etapas += "Ultrapassagem: " + carroA.getMarca() + " " + carroA.getModelo() + " ultrapassou " + ult.getMarca() + " " + ult.getModelo() + "\n";
                                        flagEtapas = true;
                                    }
                                }
                            }
                        }
                    }
                }
                resAntes = new TreeSet<>(resDepois);
                resDepois = new TreeSet<>();
                flagEtapas = false;
            }
            this.primeiroVolta(i,aux); //metodo auxiliar para determinar o 1º a cada volta
            List<Carro> antes = new ArrayList<>(resAntes);
            etapas+="Resultados da volta "+(i+1)+":\n";
            int cl = 0;
            for(cl = 0; cl<antes.size(); cl++){
                Carro carro = antes.get(cl);
                etapas+=(cl+1)+".º lugar:   Categoria:"+carro.getClass().getSimpleName()+"   Carro: "+carro.getMarca()+" "+carro.getModelo()+"   Piloto: "+carro.getPiloto().getNome()+"\n";
            }
        }
        for(Carro c : aux) {
            if(!c.getDNF()) {
                this.resultados.add(c);
            }
        }
        this.dnf = temp;
    }

    private void primeiroVolta(int volta, List<Carro> l)
    {
        Collections.sort(l);
        Iterator<Carro> it = l.iterator();
        boolean f = false;
        Carro c = null;
        while(it.hasNext() && f==false)
        {
            c = it.next();
            if(c.getDNF()==false)
                f=true;
        }
        if(c!=null)
            this.primeiroVolta.add(volta,c.clone());
    }

    private String printPrimeiroVolta()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("\n");
        sb.append("\n||||| Primeiro carro a cada volta e desistentes |||||");
        for(int i=0; i<this.primeiroVolta.size();i++)
        {
            sb.append("\n");
            sb.append(i+1);sb.append("ª Volta: ");
            sb.append(this.primeiroVolta.get(i).getMarca());sb.append(" ");
            sb.append(this.primeiroVolta.get(i).getModelo());sb.append(" ");
            sb.append(this.primeiroVolta.get(i).getPiloto().getNome());
            for(Carro c : this.dnf.keySet())
            {
                if(this.dnf.get(c) == i)
                {
                    sb.append("\n\t");sb.append("Desistente: ");
                    sb.append(c.getMarca());sb.append(" ");
                    sb.append(c.getModelo());sb.append(" ");
                    sb.append(c.getPiloto().getNome());
                }
            }
        }
        return sb.toString();
    }

    public String condicoesToString(){
        StringBuilder sb = new StringBuilder();
        int i = 1;
        sb.append("\n||||| ");sb.append(this.circuito.getNome());sb.append(" |||||");
        sb.append("\n||||| ");sb.append("Voltas: ");sb.append(this.circuito.getVoltas());sb.append(" |||||");
        sb.append("\n||||| ");sb.append("Distancia: ");sb.append(this.circuito.getDistancia());sb.append("km | ");
        sb.append("Condição meteorológica: ");
        if(this.clima == 0)
        {
            sb.append("Sol");
        }
        else
        {
            sb.append("Chuva");;
        }
        sb.append(" |||||");
        sb.append("\n||||| ");sb.append("Record: ");sb.append(TimeConverter.toTimeFormat(this.circuito.getRecord().getTempo()));
        sb.append(" | Piloto: ");sb.append(this.circuito.getRecord().getPiloto().getNome());
        sb.append(" Carro: ");sb.append(this.circuito.getRecord().getCarro().getMarca());
        sb.append(" ");sb.append(this.circuito.getRecord().getCarro().getModelo());
        sb.append(" |||||\n\n");
        return sb.toString();
    }

    public String printResultados()
    {
        StringBuilder sb = new StringBuilder();
        int i = 1;
        sb.append("\n||||| ");sb.append(this.circuito.getNome());sb.append(" |||||");
        sb.append("\n||||| ");sb.append("Voltas: ");sb.append(this.circuito.getVoltas());sb.append(" |||||");
        sb.append("\n||||| ");sb.append("Distancia: ");sb.append(this.circuito.getDistancia());sb.append("km | ");
        sb.append("Condição meteorológica: ");
        if(this.clima == 0)
        {
            sb.append("Sol");
        }
        else
        {
            sb.append("Chuva");;
        }
        sb.append(" |||||");
        sb.append("\n||||| ");sb.append("Record: ");sb.append(TimeConverter.toTimeFormat(this.circuito.getRecord().getTempo()));
        sb.append(" | Piloto: ");sb.append(this.circuito.getRecord().getPiloto().getNome());
        sb.append(" Carro: ");sb.append(this.circuito.getRecord().getCarro().getMarca());
        sb.append(" ");sb.append(this.circuito.getRecord().getCarro().getModelo());
        sb.append(" |||||\n\n");
        sb.append(etapas);
        sb.append("\n\n||||| Classificacoes da corrida |||||\n\n");
        for(Carro c : this.resultados)
        {
            sb.append("\n");
            sb.append(i);sb.append("º: ");
            sb.append(TimeConverter.toTimeFormat(c.getTempo()));
            sb.append("\t Categoria: "); sb.append(c.getClass().getSimpleName()); sb.append(" ");
            sb.append("\t Carro: "); sb.append(c.getMarca()); sb.append(" ");
            sb.append(c.getModelo());
            sb.append("\t Piloto: ");sb.append(c.getPiloto().getNome());
            i++;
        }
        for(int v=this.circuito.getVoltas();v>=0;v--)
        {
            for(Carro c : this.dnf.keySet())
            {
                if(v==this.dnf.get(c))
                {
                    sb.append("\n");
                    sb.append(i);sb.append("º: ");
                    sb.append("DNF");
                    sb.append("\t Categoria: "); sb.append(c.getClass().getSimpleName()); sb.append(" ");
                    sb.append("\t Carro: "); sb.append(c.getMarca()); sb.append(" ");
                    sb.append(c.getModelo());
                    sb.append("\t Piloto: ");sb.append(c.getPiloto().getNome());
                    i++;
                }
            }
        }

        sb.append("\n\n||||| Classificacoes da corrida Hibridos |||||");
        i=1;
        for(Carro c : this.resultados)
        {
            if(c instanceof Hibrido)
            {
                sb.append("\n");
                sb.append(i);sb.append("º: ");
                sb.append(TimeConverter.toTimeFormat(c.getTempo()));
                sb.append("\t Categoria: "); sb.append(c.getClass().getSimpleName()); sb.append(" ");
                sb.append("\t Carro: "); sb.append(c.getMarca()); sb.append(" ");
                sb.append(c.getModelo());
                sb.append("\t Piloto: ");sb.append(c.getPiloto().getNome());
                i++;
            }
        }
        for(int v=this.circuito.getVoltas();v>=0;v--)
        {
            for(Carro c : this.dnf.keySet())
            {
                if(c instanceof Hibrido)
                {
                    if(v==this.dnf.get(c))
                    {
                        sb.append("\n");
                        sb.append(i);sb.append("º: ");
                        sb.append("DNF");
                        sb.append("\t Categoria: "); sb.append(c.getClass().getSimpleName()); sb.append(" ");
                        sb.append("\t Carro: "); sb.append(c.getMarca()); sb.append(" ");
                        sb.append(c.getModelo());
                        sb.append("\t Piloto: ");sb.append(c.getPiloto().getNome());
                        i++;
                    }
                }
            }
        }
        return sb.toString();
    }

    public String printDNF()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("Espetados!!!");
        for(Carro c : this.dnf.keySet())
        {
            sb.append("\n" + c.getMarca() + " \t\tVolta: " + this.dnf.get(c));
        }
        return sb.toString();
    }

    public String listaCarrosParticipantes()
    {
        StringBuilder sb = new StringBuilder();
        int i = 1;
        for(Carro c : this.listaCarros)
        {
            sb.append("\n");
            sb.append(i);sb.append(" - ");sb.append(c.getMarca());sb.append(" ");sb.append(c.getModelo());
            sb.append("\t ");sb.append(c.getPiloto().getNome());sb.append("\t ");sb.append(c.getClass().getSimpleName());
            i++;
        }
        return sb.toString();
    }

    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("Circuito: ");sb.append(this.circuito);
        //sb.append("\nCarros: ");sb.append(this.listaCarros);
        return sb.toString();
    }
}

    class tempoComp implements Comparator<Carro>{

        @Override
        public int compare(Carro c1, Carro c2) {
            if(c1.getMarca().equals(c2.getMarca()) && c1.getModelo().equals(c2.getModelo())) return 0;
            if(c1.getTempo() < c2.getTempo()){
                return 1;
            } else {
                return -1;
            }
        }
    }
