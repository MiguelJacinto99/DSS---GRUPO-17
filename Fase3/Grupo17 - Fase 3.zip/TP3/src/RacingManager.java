import View.View;
import java.io.IOException;
import Controller.Controller;
import RacingManagerLN.*;

public class RacingManager {
    public static void main(String[] args) throws IOException {
        View view = new View();
        IRacingManagerLN iRacingManagerLN = new RacingManagerLN();
        Controller controller = new Controller(view,iRacingManagerLN);
        controller.start();
    }
}
